import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { ArrowLeftRight, Play, Pause, XCircle, RotateCcw, ChevronRight } from 'lucide-react'
import { accountsApi, transfersApi } from '@/services/api'
import { useTransferProgress } from '@/hooks/useTransferProgress'
import { PROVIDER_META, formatBytes, formatSpeed, formatEta } from '@/utils/providers'
import type { CloudAccount, Transfer, TransferMode } from '@/types'
import { formatDistanceToNow } from 'date-fns'

export default function TransferPage() {
  const qc = useQueryClient()
  const [activeTransferId, setActiveTransferId] = useState<string | null>(null)
  const [form, setForm] = useState({
    source_account_id: '',
    destination_account_id: '',
    source_path: '/',
    destination_path: '/',
    mode: 'copy' as TransferMode,
  })

  const { data: accountsResp } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => accountsApi.list(),
    select: (r) => r.data as CloudAccount[],
  })

  const { data: transfers, isLoading: transfersLoading } = useQuery({
    queryKey: ['transfers'],
    queryFn: () => transfersApi.list({ limit: 30 }),
    select: (r) => r.data as Transfer[],
    refetchInterval: 5000,
  })

  const createMutation = useMutation({
    mutationFn: transfersApi.create,
    onSuccess: (res) => {
      const t = res.data as Transfer
      setActiveTransferId(t.id)
      qc.invalidateQueries({ queryKey: ['transfers'] })
      toast.success('Transfer started!')
    },
    onError: (err: any) => {
      toast.error(err.response?.data?.detail || 'Failed to start transfer')
    },
  })

  const pauseMutation = useMutation({
    mutationFn: transfersApi.pause,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['transfers'] }); toast('Transfer paused') },
  })

  const resumeMutation = useMutation({
    mutationFn: transfersApi.resume,
    onSuccess: (_, id) => { setActiveTransferId(id); qc.invalidateQueries({ queryKey: ['transfers'] }) },
  })

  const cancelMutation = useMutation({
    mutationFn: transfersApi.cancel,
    onSuccess: () => { setActiveTransferId(null); qc.invalidateQueries({ queryKey: ['transfers'] }) },
  })

  const accounts = accountsResp || []

  const handleStart = () => {
    if (!form.source_account_id || !form.destination_account_id) {
      toast.error('Select source and destination accounts')
      return
    }
    if (form.source_account_id === form.destination_account_id && form.source_path === form.destination_path) {
      toast.error('Source and destination cannot be the same')
      return
    }
    createMutation.mutate(form)
  }

  const swap = () => {
    setForm((f) => ({
      ...f,
      source_account_id: f.destination_account_id,
      destination_account_id: f.source_account_id,
      source_path: f.destination_path,
      destination_path: f.source_path,
    }))
  }

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <h1 className="text-base font-semibold text-slate-800">New Transfer</h1>

      {/* Form card */}
      <div className="card p-5">
        <div className="grid grid-cols-[1fr_auto_1fr] gap-3 items-end mb-4">
          <AccountSelect
            label="Source"
            accounts={accounts}
            value={form.source_account_id}
            onChange={(v) => setForm((f) => ({ ...f, source_account_id: v }))}
            pathValue={form.source_path}
            onPathChange={(v) => setForm((f) => ({ ...f, source_path: v }))}
          />

          <button
            onClick={swap}
            className="mb-0.5 p-2.5 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-600 transition-all text-slate-500"
            title="Swap source and destination"
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>

          <AccountSelect
            label="Destination"
            accounts={accounts}
            value={form.destination_account_id}
            onChange={(v) => setForm((f) => ({ ...f, destination_account_id: v }))}
            pathValue={form.destination_path}
            onPathChange={(v) => setForm((f) => ({ ...f, destination_path: v }))}
          />
        </div>

        <div className="flex items-center gap-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Transfer mode</label>
            <select
              className="select text-sm w-40"
              value={form.mode}
              onChange={(e) => setForm((f) => ({ ...f, mode: e.target.value as TransferMode }))}
            >
              <option value="copy">Copy (keep source)</option>
              <option value="move">Move (delete source)</option>
              <option value="mirror">Mirror (one-way sync)</option>
            </select>
          </div>

          <button
            onClick={handleStart}
            disabled={createMutation.isPending}
            className="mt-5 btn-primary flex items-center gap-2 px-5 py-2.5"
          >
            {createMutation.isPending
              ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              : <Play className="w-4 h-4" />
            }
            Start Transfer
          </button>
        </div>
      </div>

      {/* Live progress */}
      <AnimatePresence>
        {activeTransferId && (
          <LiveProgress
            transferId={activeTransferId}
            onPause={() => pauseMutation.mutate(activeTransferId)}
            onCancel={() => cancelMutation.mutate(activeTransferId)}
            onClose={() => setActiveTransferId(null)}
          />
        )}
      </AnimatePresence>

      {/* History */}
      <div className="card">
        <div className="p-4 border-b border-slate-100">
          <h2 className="text-sm font-semibold text-slate-700">Transfer History</h2>
        </div>
        {transfersLoading ? (
          <div className="p-8 text-center text-sm text-slate-400">Loading…</div>
        ) : !transfers?.length ? (
          <div className="p-8 text-center text-sm text-slate-400">No transfers yet. Start one above!</div>
        ) : (
          <div className="divide-y divide-slate-50">
            {transfers.map((t) => (
              <TransferRow
                key={t.id}
                transfer={t}
                accounts={accounts}
                onResume={() => { resumeMutation.mutate(t.id); setActiveTransferId(t.id) }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function AccountSelect({
  label, accounts, value, onChange, pathValue, onPathChange,
}: {
  label: string
  accounts: CloudAccount[]
  value: string
  onChange: (v: string) => void
  pathValue: string
  onPathChange: (v: string) => void
}) {
  return (
    <div>
      <label className="block text-xs text-slate-500 mb-1">{label}</label>
      <select className="select text-sm mb-2" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">— Select account —</option>
        {accounts.map((a) => (
          <option key={a.id} value={a.id}>
            {PROVIDER_META[a.provider]?.icon} {a.display_name}
          </option>
        ))}
      </select>
      <input
        className="input text-sm"
        placeholder="Folder path (e.g. /Documents)"
        value={pathValue}
        onChange={(e) => onPathChange(e.target.value)}
      />
    </div>
  )
}

function LiveProgress({
  transferId, onPause, onCancel, onClose,
}: {
  transferId: string
  onPause: () => void
  onCancel: () => void
  onClose: () => void
}) {
  const { progress } = useTransferProgress(transferId)

  const status = progress?.status
  const pct = progress?.percent ?? 0
  const isDone = ['completed', 'failed', 'cancelled'].includes(status ?? '')

  const statusColor = {
    completed: 'text-green-600',
    failed: 'text-red-500',
    cancelled: 'text-slate-400',
    running: 'text-blue-600',
    paused: 'text-amber-500',
    pending: 'text-slate-500',
  }[status ?? 'pending'] ?? 'text-slate-500'

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="card p-5"
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="text-sm font-semibold text-slate-800">
            {isDone ? (status === 'completed' ? '✅ Transfer complete' : status === 'failed' ? '❌ Transfer failed' : '⊘ Cancelled') : 'Transferring…'}
          </div>
          {progress?.error_message && (
            <p className="text-xs text-red-500 mt-0.5">{progress.error_message}</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-sm font-semibold ${statusColor}`}>{Math.round(pct)}%</span>
          {!isDone && (
            <>
              <button onClick={onPause} className="btn-ghost p-1.5" title="Pause">
                <Pause className="w-4 h-4" />
              </button>
              <button onClick={onCancel} className="text-red-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50 transition-all" title="Cancel">
                <XCircle className="w-4 h-4" />
              </button>
            </>
          )}
          {isDone && (
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-xs px-2 py-1 rounded">
              Dismiss
            </button>
          )}
        </div>
      </div>

      {/* Progress bar */}
      <div className="h-2 bg-slate-100 rounded-full overflow-hidden mb-3">
        <motion.div
          className={`h-full rounded-full ${status === 'completed' ? 'bg-green-500' : status === 'failed' ? 'bg-red-400' : 'bg-blue-600'}`}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
        />
      </div>

      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>{progress?.transferred_files ?? 0} / {progress?.total_files ?? 0} files</span>
        <span>{formatBytes(progress?.transferred_bytes ?? 0)} / {formatBytes(progress?.total_bytes ?? 0)}</span>
        <span className="text-blue-600 font-medium">{formatSpeed(progress?.speed_mbps ?? 0)}</span>
        {progress?.eta_seconds && !isDone && (
          <span>ETA: {formatEta(progress.eta_seconds)}</span>
        )}
        {(progress?.failed_files ?? 0) > 0 && (
          <span className="text-red-500">{progress!.failed_files} failed</span>
        )}
      </div>
    </motion.div>
  )
}

function TransferRow({ transfer, accounts, onResume }: {
  transfer: Transfer
  accounts: CloudAccount[]
  onResume: () => void
}) {
  const src = accounts.find((a) => a.id === transfer.source_account_id)
  const dst = accounts.find((a) => a.id === transfer.destination_account_id)
  const pct = transfer.total_bytes > 0
    ? Math.round((transfer.transferred_bytes / transfer.total_bytes) * 100)
    : transfer.total_files > 0
    ? Math.round((transfer.transferred_files / transfer.total_files) * 100)
    : 0

  const statusBadge = {
    completed: 'bg-green-50 text-green-700',
    failed: 'bg-red-50 text-red-600',
    running: 'bg-blue-50 text-blue-700',
    paused: 'bg-amber-50 text-amber-700',
    pending: 'bg-slate-100 text-slate-600',
    cancelled: 'bg-slate-100 text-slate-500',
  }[transfer.status] ?? 'bg-slate-100 text-slate-500'

  return (
    <div className="flex items-center gap-3 px-4 py-3">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 text-sm text-slate-700 mb-0.5">
          <span className="truncate">{src?.display_name ?? '—'}</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="truncate">{dst?.display_name ?? '—'}</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-slate-400">
          <span>{transfer.transferred_files}/{transfer.total_files} files</span>
          <span>{formatBytes(transfer.transferred_bytes)}</span>
          <span>{formatDistanceToNow(new Date(transfer.created_at), { addSuffix: true })}</span>
        </div>
        {transfer.status === 'running' && (
          <div className="mt-1.5 h-1 bg-slate-100 rounded-full overflow-hidden w-40">
            <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
          </div>
        )}
      </div>
      <span className={`badge ${statusBadge}`}>{transfer.status}</span>
      {transfer.status === 'paused' && (
        <button onClick={onResume} className="text-blue-600 hover:text-blue-700 p-1 rounded" title="Resume">
          <RotateCcw className="w-4 h-4" />
        </button>
      )}
    </div>
  )
}
