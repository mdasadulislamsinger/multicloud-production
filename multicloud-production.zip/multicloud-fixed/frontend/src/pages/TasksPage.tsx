import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import { CalendarClock, Plus, Trash2, ToggleLeft, ToggleRight, X } from 'lucide-react'
import { accountsApi, tasksApi } from '@/services/api'
import { PROVIDER_META } from '@/utils/providers'
import type { CloudAccount, ScheduledTask } from '@/types'
import { formatDistanceToNow } from 'date-fns'
import { AnimatePresence, motion } from 'framer-motion'

export default function TasksPage() {
  const qc = useQueryClient()
  const [showModal, setShowModal] = useState(false)

  const { data: tasks, isLoading } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => tasksApi.list(),
    select: (r) => r.data as ScheduledTask[],
    refetchInterval: 15_000,
  })

  const { data: accounts } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => accountsApi.list(),
    select: (r) => r.data as CloudAccount[],
  })

  const toggleMutation = useMutation({
    mutationFn: tasksApi.toggle,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  })

  const deleteMutation = useMutation({
    mutationFn: tasksApi.delete,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['tasks'] }); toast.success('Task deleted') },
  })

  const accts = accounts || []

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-base font-semibold text-slate-800">Scheduled Tasks</h1>
        <button onClick={() => setShowModal(true)} className="btn-primary flex items-center gap-2 text-sm py-2">
          <Plus className="w-4 h-4" /> New Task
        </button>
      </div>

      <div className="card">
        {isLoading ? (
          <div className="p-8 text-center text-sm text-slate-400">Loading…</div>
        ) : !tasks?.length ? (
          <div className="p-10 text-center">
            <CalendarClock className="w-8 h-8 text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-slate-500">No scheduled tasks yet.</p>
            <p className="text-xs text-slate-400 mt-1">Create a task to automatically transfer or sync files.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-50">
            {tasks.map((task) => {
              const src = accts.find(a => a.id === task.source_account_id)
              const dst = accts.find(a => a.id === task.destination_account_id)
              return (
                <div key={task.id} className="flex items-start gap-3 px-4 py-3.5">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-sm font-medium text-slate-800 truncate">{task.name}</span>
                      <span className="badge bg-blue-50 text-blue-600 capitalize">{task.task_type}</span>
                      <span className="badge bg-slate-100 text-slate-500 capitalize">{task.schedule_type}</span>
                    </div>
                    <p className="text-xs text-slate-400 truncate">
                      {src?.display_name ?? '?'} → {dst?.display_name ?? '?'}
                    </p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-400">
                      <span>Runs: {task.run_count}×</span>
                      {task.last_run_at && <span>Last: {formatDistanceToNow(new Date(task.last_run_at), { addSuffix: true })}</span>}
                      {task.next_run_at && <span>Next: {formatDistanceToNow(new Date(task.next_run_at), { addSuffix: true })}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => toggleMutation.mutate(task.id)}
                      className="text-slate-400 hover:text-blue-600 p-1.5 rounded-lg transition-all"
                      title={task.is_active ? 'Pause' : 'Resume'}
                    >
                      {task.is_active
                        ? <ToggleRight className="w-5 h-5 text-green-500" />
                        : <ToggleLeft className="w-5 h-5 text-slate-400" />
                      }
                    </button>
                    <button
                      onClick={() => deleteMutation.mutate(task.id)}
                      className="text-slate-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition-all"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <AnimatePresence>
        {showModal && (
          <CreateTaskModal
            accounts={accts}
            onClose={() => setShowModal(false)}
            onSuccess={() => { setShowModal(false); qc.invalidateQueries({ queryKey: ['tasks'] }) }}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

function CreateTaskModal({ accounts, onClose, onSuccess }: {
  accounts: CloudAccount[]
  onClose: () => void
  onSuccess: () => void
}) {
  const [form, setForm] = useState({
    name: '',
    task_type: 'transfer',
    source_account_id: '',
    destination_account_id: '',
    source_path: '/',
    destination_path: '/',
    schedule_type: 'daily',
  })

  const mutation = useMutation({
    mutationFn: tasksApi.create,
    onSuccess: () => { toast.success('Task scheduled!'); onSuccess() },
    onError: (e: any) => toast.error(e.response?.data?.detail || 'Failed to create task'),
  })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-base font-semibold text-slate-800">New Scheduled Task</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-slate-400" /></button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs text-slate-500 block mb-1">Task name</label>
            <input className="input text-sm" placeholder="Daily backup to S3" value={form.name} onChange={set('name')} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 block mb-1">Task type</label>
              <select className="select text-sm" value={form.task_type} onChange={set('task_type')}>
                <option value="transfer">Transfer</option>
                <option value="sync">Sync</option>
                <option value="backup">Backup</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">Schedule</label>
              <select className="select text-sm" value={form.schedule_type} onChange={set('schedule_type')}>
                <option value="once">Once</option>
                <option value="hourly">Hourly</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
              </select>
            </div>
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">Source account</label>
            <select className="select text-sm" value={form.source_account_id} onChange={set('source_account_id')}>
              <option value="">— Select —</option>
              {accounts.map(a => <option key={a.id} value={a.id}>{PROVIDER_META[a.provider]?.icon} {a.display_name}</option>)}
            </select>
            <input className="input text-sm mt-2" placeholder="Source path" value={form.source_path} onChange={set('source_path')} />
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">Destination account</label>
            <select className="select text-sm" value={form.destination_account_id} onChange={set('destination_account_id')}>
              <option value="">— Select —</option>
              {accounts.map(a => <option key={a.id} value={a.id}>{PROVIDER_META[a.provider]?.icon} {a.display_name}</option>)}
            </select>
            <input className="input text-sm mt-2" placeholder="Destination path" value={form.destination_path} onChange={set('destination_path')} />
          </div>
          <button
            className="btn-primary w-full mt-2"
            onClick={() => mutation.mutate(form)}
            disabled={mutation.isPending}
          >
            {mutation.isPending ? 'Scheduling…' : 'Create Task'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}
