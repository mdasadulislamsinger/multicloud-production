import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import { Folder, File, Trash2, FolderPlus, ChevronRight, Loader2 } from 'lucide-react'
import { accountsApi, filesApi } from '@/services/api'
import { PROVIDER_META, formatBytes } from '@/utils/providers'
import type { CloudAccount, FileItem } from '@/types'
import { formatDistanceToNow } from 'date-fns'

export default function FilesPage() {
  const [selectedAccount, setSelectedAccount] = useState<string>('')
  const [path, setPath] = useState('/')

  const { data: accounts } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => accountsApi.list(),
    select: (r) => r.data as CloudAccount[],
  })

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['files', selectedAccount, path],
    queryFn: () => filesApi.list(selectedAccount, path),
    select: (r) => r.data.files as FileItem[],
    enabled: !!selectedAccount,
  })

  const qc = useQueryClient()

  const deleteMutation = useMutation({
    mutationFn: ({ path: p }: { path: string }) => filesApi.delete(selectedAccount, p),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['files', selectedAccount, path] }); toast.success('Deleted') },
    onError: () => toast.error('Delete failed'),
  })

  const mkdirMutation = useMutation({
    mutationFn: (newPath: string) => filesApi.createFolder(selectedAccount, newPath),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['files', selectedAccount, path] }); toast.success('Folder created') },
  })

  const accts = accounts || []
  const files = data || []

  const pathParts = path.split('/').filter(Boolean)

  const navigate = (newPath: string) => setPath(newPath || '/')

  const handleNewFolder = () => {
    const name = prompt('Folder name:')
    if (!name) return
    mkdirMutation.mutate(`${path.replace(/\/$/, '')}/${name}`)
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center gap-3">
        <h1 className="text-base font-semibold text-slate-800">File Browser</h1>
        {isFetching && <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />}
      </div>

      {/* Account picker */}
      <div className="flex gap-2 flex-wrap">
        {accts.map((a) => {
          const meta = PROVIDER_META[a.provider]
          return (
            <button
              key={a.id}
              onClick={() => { setSelectedAccount(a.id); setPath('/') }}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${selectedAccount === a.id ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'}`}
            >
              <span>{meta?.icon}</span>
              {a.display_name}
            </button>
          )
        })}
        {!accts.length && (
          <p className="text-sm text-slate-400">No accounts connected. <a href="/dashboard/accounts" className="text-blue-600 underline">Connect one</a>.</p>
        )}
      </div>

      {selectedAccount && (
        <div className="card">
          {/* Breadcrumb + toolbar */}
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-100">
            <div className="flex items-center gap-1 text-xs text-slate-500 flex-wrap">
              <button onClick={() => navigate('/')} className="hover:text-blue-600 transition-colors">Root</button>
              {pathParts.map((p, i) => (
                <span key={i} className="flex items-center gap-1">
                  <ChevronRight className="w-3 h-3" />
                  <button
                    onClick={() => navigate('/' + pathParts.slice(0, i + 1).join('/'))}
                    className="hover:text-blue-600 transition-colors"
                  >
                    {p}
                  </button>
                </span>
              ))}
            </div>
            <button onClick={handleNewFolder} className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-blue-600 transition-colors">
              <FolderPlus className="w-3.5 h-3.5" /> New folder
            </button>
          </div>

          {/* File list */}
          {isLoading ? (
            <div className="p-10 text-center text-sm text-slate-400">
              <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2 text-blue-500" />
              Loading files…
            </div>
          ) : !files.length ? (
            <div className="p-10 text-center text-sm text-slate-400">This folder is empty.</div>
          ) : (
            <div className="divide-y divide-slate-50">
              {files.map((file) => (
                <div key={file.id} className="flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 group">
                  {file.is_folder ? (
                    <Folder className="w-4 h-4 text-blue-400 shrink-0" />
                  ) : (
                    <File className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                  <button
                    className="flex-1 text-left text-sm text-slate-700 truncate hover:text-blue-600 transition-colors"
                    onClick={() => file.is_folder && navigate(file.path)}
                  >
                    {file.name}
                  </button>
                  <span className="text-xs text-slate-400 shrink-0 hidden md:block">
                    {file.size ? formatBytes(file.size) : ''}
                  </span>
                  <span className="text-xs text-slate-300 shrink-0 hidden lg:block">
                    {file.modified_at ? formatDistanceToNow(new Date(file.modified_at), { addSuffix: true }) : ''}
                  </span>
                  <button
                    onClick={() => deleteMutation.mutate({ path: file.path })}
                    className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 p-1 rounded transition-all"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
