import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { authApi } from '@/services/api'

export default function LoginPage() {
  const navigate = useNavigate()

  const handleGoogle = () => {
    window.location.href = authApi.googleLoginUrl()
  }

  const handleMicrosoft = () => {
    window.location.href = authApi.microsoftLoginUrl()
  }

  return (
    <div className="min-h-screen bg-navy-800 flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-3">
            <svg width="36" height="28" viewBox="0 0 36 28">
              <ellipse cx="12" cy="21" rx="10" ry="5.5" fill="#4DA6FF" opacity=".9" />
              <ellipse cx="12" cy="15" rx="7.5" ry="5.5" fill="#80CCFF" />
              <ellipse cx="18" cy="13" rx="5.5" ry="4.5" fill="#fff" opacity=".9" />
              <ellipse cx="26" cy="19" rx="8" ry="5" fill="#4DA6FF" opacity=".85" />
              <ellipse cx="26" cy="14" rx="5.5" ry="4" fill="#80CCFF" />
              <ellipse cx="30" cy="11" rx="4" ry="3.5" fill="#fff" opacity=".85" />
            </svg>
            <span className="text-white text-xl font-semibold">Multi<span className="text-blue-400">Cloud</span></span>
          </div>
          <p className="text-slate-400 text-sm">Sign in to manage your cloud transfers</p>
        </div>

        {/* Card */}
        <div className="bg-white/8 backdrop-blur border border-white/15 rounded-2xl p-8 shadow-2xl">
          <h1 className="text-white text-lg font-semibold text-center mb-6">Welcome back</h1>

          <div className="flex flex-col gap-3">
            <button
              onClick={handleGoogle}
              className="flex items-center justify-center gap-3 bg-white hover:bg-gray-50 text-gray-800 font-medium px-4 py-3 rounded-xl transition-all active:scale-95 text-sm"
            >
              <GoogleIcon />
              Continue with Google
            </button>

            <button
              onClick={handleMicrosoft}
              className="flex items-center justify-center gap-3 bg-[#0078d4] hover:bg-[#006cbf] text-white font-medium px-4 py-3 rounded-xl transition-all active:scale-95 text-sm"
            >
              <MicrosoftIcon />
              Continue with Microsoft
            </button>
          </div>

          <div className="mt-6 pt-5 border-t border-white/10 text-center">
            <p className="text-xs text-slate-500">
              By signing in you agree to our{' '}
              <a href="#" className="text-blue-400 hover:underline">Terms</a>{' '}
              and{' '}
              <a href="#" className="text-blue-400 hover:underline">Privacy Policy</a>.
            </p>
          </div>
        </div>

        <div className="text-center mt-6">
          <button onClick={() => navigate('/')} className="text-slate-500 hover:text-slate-300 text-xs transition-colors">
            ← Back to home
          </button>
        </div>
      </motion.div>
    </div>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48">
      <path fill="#FFC107" d="M43.6 20H24v8h11.3C33.6 33.1 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20c11 0 20-8.9 20-20 0-1.3-.1-2.7-.4-4z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.5 15.1 18.9 12 24 12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-1.9 13.5-5.1l-6.2-5.2C29.5 35.6 26.9 36 24 36c-5.2 0-9.6-2.9-11.7-7.2l-6.6 5.1C9.7 39.7 16.3 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20H24v8h11.3c-.8 2.3-2.4 4.2-4.4 5.5l6.2 5.2C41.4 35.4 44 30.1 44 24c0-1.3-.1-2.7-.4-4z" />
    </svg>
  )
}

function MicrosoftIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 21 21">
      <rect x="1" y="1" width="9" height="9" fill="#f25022" />
      <rect x="11" y="1" width="9" height="9" fill="#7fba00" />
      <rect x="1" y="11" width="9" height="9" fill="#00a4ef" />
      <rect x="11" y="11" width="9" height="9" fill="#ffb900" />
    </svg>
  )
}
