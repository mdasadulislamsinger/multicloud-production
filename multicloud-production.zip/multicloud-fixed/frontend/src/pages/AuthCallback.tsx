import { useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import toast from 'react-hot-toast'

export default function AuthCallback() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const login = useAuthStore((s) => s.login)

  useEffect(() => {
    const accessToken = params.get('access_token')
    const refreshToken = params.get('refresh_token')

    if (!accessToken || !refreshToken) {
      toast.error('Authentication failed. Please try again.')
      navigate('/login')
      return
    }

    login(accessToken, refreshToken).then(() => {
      toast.success('Signed in successfully!')
      navigate('/dashboard')
    })
  }, [])

  return (
    <div className="min-h-screen bg-navy-800 flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-slate-400 text-sm">Completing sign in…</p>
      </div>
    </div>
  )
}
