import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { Plus, Trash2, X, HardDrive, CheckCircle } from 'lucide-react'
import { accountsApi } from '@/services/api'
import { PROVIDER_META, formatBytes } from '@/utils/providers'
import type { CloudAccount, CloudProvider } from '@/types'

const OAUTH_PROVIDERS: { id: CloudProvider; label: string; desc: string }[] = [
  { id: 'google_drive', label: 'Google Drive', desc: 'Connect via Google OAuth' },
  { id: 'onedrive', label: 'OneDrive', desc: 'Connect via Microsoft OAuth' },
  { id: 'dropbox', label: 'Dropbox', desc: 'Connect via Dropbox OAuth' },
]

type ModalType = null | 's3' | 'ftp'

export default function AccountsPage() {
  const qc = useQueryClient()
  const [modal, setModal] = useState<ModalType>(null)

  const { data: accounts, isLoading } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => accountsApi.list(),
    select: (r) => r.data as CloudAccount[],
  })

  const disconnectMutation = useMutation({
    mutationFn: accountsApi.disconnect,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['accounts'] })
      toast.success('Account disconnected')
    },
  })

  const connectOAuth = async (provider: CloudProvider) => {
    try {
      let url: string
      if (provider === 'google_drive') url = await accountsApi.connectGoogleDrive()
      else if (provider === 'onedrive') url = await accountsApi.connectOneDrive()
      else if (provider === 'dropbox') url = await accountsApi.connectDropbox()
      else return
      window.location.href = url
    } catch {
      toast.error('Failed to initiate OAuth flow')
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-base font-semibold text-slate-800">Connected Accounts</h1>
        <div className="flex gap-2">
          <button onClick={() => setModal('s3')} className="btn-secondary text-xs flex items-center gap-1.5 py-1.5">
            <Plus className="w-3.5 h-3.5" /> Add S3
          </button>
          <button onClick={() => setModal('ftp')} className="btn-secondary text-xs flex items-center gap-1.5 py-1.5">
            <Plus className="w-3.5 h-3.5" /> Add FTP/SFTP
          </button>
        </div>
      </div>

      {/* Connected accounts */}
      <div className="card divide-y divide-slate-50">
        {isLoading ? (
          <div className="p-8 text-center text-sm text-slate-400">Loading accounts…</div>
        ) : !accounts?.length ? (
          <div className="p-8 text-center text-sm text-slate-400">No accounts connected yet.</div>
        ) : (
          accounts.map((account) => (
            <AccountRow
              key={account.id}
              account={account}
              onDisconnect={() => disconnectMutation.mutate(account.id)}
            />
          ))
        )}
      </div>

      {/* Connect new */}
      <h2 className="text-sm font-semibold text-slate-600 pt-2">Connect a new account</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {OAUTH_PROVIDERS.map(({ id, label, desc }) => {
          const meta = PROVIDER_META[id]
          return (
            <button
              key={id}
              onClick={() => connectOAuth(id)}
              className="card p-4 text-left hover:border-blue-300 hover:shadow-md transition-all active:scale-98 flex flex-col gap-2"
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center text-lg"
                style={{ background: meta.bg }}
              >
                {meta.icon}
              </div>
              <div>
                <div className="text-sm font-medium text-slate-800">{label}</div>
                <div className="text-xs text-slate-500">{desc}</div>
              </div>
            </button>
          )
        })}

        <button
          onClick={() => setModal('s3')}
          className="card p-4 text-left hover:border-blue-300 hover:shadow-md transition-all active:scale-98 flex flex-col gap-2"
        >
          <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center text-lg">🪣</div>
          <div>
            <div className="text-sm font-medium text-slate-800">Amazon S3</div>
            <div className="text-xs text-slate-500">Access Key + Secret</div>
          </div>
        </button>

        <button
          onClick={() => setModal('ftp')}
          className="card p-4 text-left hover:border-blue-300 hover:shadow-md transition-all active:scale-98 flex flex-col gap-2"
        >
          <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-lg">🖥️</div>
          <div>
            <div className="text-sm font-medium text-slate-800">FTP / SFTP</div>
            <div className="text-xs text-slate-500">Host + credentials</div>
          </div>
        </button>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {modal === 's3' && <S3Modal onClose={() => setModal(null)} onSuccess={() => { setModal(null); qc.invalidateQueries({ queryKey: ['accounts'] }) }} />}
        {modal === 'ftp' && <FTPModal onClose={() => setModal(null)} onSuccess={() => { setModal(null); qc.invalidateQueries({ queryKey: ['accounts'] }) }} />}
      </AnimatePresence>
    </div>
  )
}

function AccountRow({ account, onDisconnect }: { account: CloudAccount; onDisconnect: () => void }) {
  const meta = PROVIDER_META[account.provider]
  const usedPct = account.storage_total_bytes > 0
    ? (account.storage_used_bytes / account.storage_total_bytes) * 100
    : 0

  return (
    <div className="flex items-center gap-3 px-4 py-3.5">
      <div className="w-9 h-9 rounded-lg flex items-center justify-center text-xl shrink-0" style={{ background: meta?.bg }}>
        {meta?.icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-slate-800 truncate">{account.display_name}</span>
          <CheckCircle className="w-3.5 h-3.5 text-green-500 shrink-0" />
        </div>
        {account.account_email && (
          <p className="text-xs text-slate-400 truncate">{account.account_email}</p>
        )}
        {account.storage_total_bytes > 0 && (
          <div className="flex items-center gap-2 mt-1.5">
            <div className="flex-1 h-1 bg-slate-100 rounded-full overflow-hidden max-w-32">
              <div
                className="h-full bg-blue-500 rounded-full"
                style={{ width: `${Math.min(usedPct, 100)}%` }}
              />
            </div>
            <span className="text-xs text-slate-400">
              {formatBytes(account.storage_used_bytes)} / {formatBytes(account.storage_total_bytes)}
            </span>
          </div>
        )}
      </div>
      <button
        onClick={onDisconnect}
        className="text-slate-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition-all"
        title="Disconnect"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  )
}

function S3Modal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [form, setForm] = useState({ display_name: '', access_key_id: '', secret_access_key: '', region: 'us-east-1', bucket_name: '' })
  const mutation = useMutation({
    mutationFn: accountsApi.connectS3,
    onSuccess: () => { toast.success('S3 connected!'); onSuccess() },
    onError: (e: any) => toast.error(e.response?.data?.detail || 'Failed to connect S3'),
  })

  return (
    <ModalWrap title="Connect Amazon S3" onClose={onClose}>
      <div className="space-y-3">
        <Field label="Display name" value={form.display_name} onChange={(v) => setForm(f => ({ ...f, display_name: v }))} placeholder="My S3 Bucket" />
        <Field label="Access Key ID" value={form.access_key_id} onChange={(v) => setForm(f => ({ ...f, access_key_id: v }))} placeholder="AKIA..." />
        <Field label="Secret Access Key" value={form.secret_access_key} onChange={(v) => setForm(f => ({ ...f, secret_access_key: v }))} type="password" placeholder="••••••••" />
        <Field label="Region" value={form.region} onChange={(v) => setForm(f => ({ ...f, region: v }))} placeholder="us-east-1" />
        <Field label="Bucket name (optional)" value={form.bucket_name} onChange={(v) => setForm(f => ({ ...f, bucket_name: v }))} placeholder="my-bucket" />
        <button className="btn-primary w-full mt-1" onClick={() => mutation.mutate(form)} disabled={mutation.isPending}>
          {mutation.isPending ? 'Connecting…' : 'Connect S3'}
        </button>
      </div>
    </ModalWrap>
  )
}

function FTPModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [form, setForm] = useState({ display_name: '', host: '', port: 22, username: '', password: '', protocol: 'sftp' })
  const mutation = useMutation({
    mutationFn: accountsApi.connectFTP,
    onSuccess: () => { toast.success('FTP/SFTP connected!'); onSuccess() },
    onError: (e: any) => toast.error(e.response?.data?.detail || 'Failed to connect'),
  })

  return (
    <ModalWrap title="Connect FTP / SFTP" onClose={onClose}>
      <div className="space-y-3">
        <Field label="Display name" value={form.display_name} onChange={(v) => setForm(f => ({ ...f, display_name: v }))} placeholder="My FTP Server" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Protocol" value={form.protocol} onChange={(v) => setForm(f => ({ ...f, protocol: v }))} type="select" options={['sftp', 'ftp']} />
          <Field label="Port" value={String(form.port)} onChange={(v) => setForm(f => ({ ...f, port: parseInt(v) || 22 }))} placeholder="22" />
        </div>
        <Field label="Host" value={form.host} onChange={(v) => setForm(f => ({ ...f, host: v }))} placeholder="ftp.example.com" />
        <Field label="Username" value={form.username} onChange={(v) => setForm(f => ({ ...f, username: v }))} placeholder="user" />
        <Field label="Password" value={form.password} onChange={(v) => setForm(f => ({ ...f, password: v }))} type="password" placeholder="••••••••" />
        <button className="btn-primary w-full mt-1" onClick={() => mutation.mutate(form)} disabled={mutation.isPending}>
          {mutation.isPending ? 'Connecting…' : 'Connect'}
        </button>
      </div>
    </ModalWrap>
  )
}

function ModalWrap({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-base font-semibold text-slate-800">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1 rounded"><X className="w-5 h-5" /></button>
        </div>
        {children}
      </motion.div>
    </motion.div>
  )
}

function Field({ label, value, onChange, type = 'text', placeholder, options }: {
  label: string; value: string; onChange: (v: string) => void
  type?: string; placeholder?: string; options?: string[]
}) {
  return (
    <div>
      <label className="block text-xs text-slate-500 mb-1">{label}</label>
      {type === 'select' ? (
        <select className="select text-sm" value={value} onChange={(e) => onChange(e.target.value)}>
          {options?.map(o => <option key={o} value={o}>{o.toUpperCase()}</option>)}
        </select>
      ) : (
        <input className="input text-sm" type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
      )}
    </div>
  )
}
