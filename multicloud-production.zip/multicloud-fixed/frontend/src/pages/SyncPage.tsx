import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import { FolderSync, Plus } from 'lucide-react'
import { accountsApi, transfersApi } from '@/services/api'
import { PROVIDER_META } from '@/utils/providers'
import type { CloudAccount } from '@/types'

export default function SyncPage() {
  const qc = useQueryClient()
  const [form, setForm] = useState({
    source_account_id: '', destination_account_id: '',
    source_path: '/', destination_path: '/',
    mode: 'mirror' as const,
  })

  const { data: accounts } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => accountsApi.list(),
    select: (r) => r.data as CloudAccount[],
  })

  const { data: transfers } = useQuery({
    queryKey: ['transfers', { mode: 'mirror' }],
    queryFn: () => transfersApi.list({ limit: 20 }),
    select: (r) => (r.data as any[]).filter(t => t.mode === 'mirror'),
    refetchInterval: 8000,
  })

  const syncMutation = useMutation({
    mutationFn: transfersApi.create,
    onSuccess: () => { toast.success('Sync task created!'); qc.invalidateQueries({ queryKey: ['transfers'] }) },
    onError: (e: any) => toast.error(e.response?.data?.detail || 'Failed to create sync'),
  })

  const handleSync = () => {
    if (!form.source_account_id || !form.destination_account_id) {
      toast.error('Select both accounts')
      return
    }
    syncMutation.mutate(form)
  }

  const accts = accounts || []

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <h1 className="text-base font-semibold text-slate-800">Cloud Sync</h1>

      <div className="card p-5">
        <h2 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
          <FolderSync className="w-4 h-4 text-blue-600" /> Configure sync
        </h2>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Source account</label>
            <select className="select text-sm" value={form.source_account_id} onChange={e => setForm(f => ({ ...f, source_account_id: e.target.value }))}>
              <option value="">— Select —</option>
              {accts.map(a => <option key={a.id} value={a.id}>{PROVIDER_META[a.provider]?.icon} {a.display_name}</option>)}
            </select>
            <input className="input text-sm mt-2" placeholder="/path" value={form.source_path} onChange={e => setForm(f => ({ ...f, source_path: e.target.value }))} />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Destination account</label>
            <select className="select text-sm" value={form.destination_account_id} onChange={e => setForm(f => ({ ...f, destination_account_id: e.target.value }))}>
              <option value="">— Select —</option>
              {accts.map(a => <option key={a.id} value={a.id}>{PROVIDER_META[a.provider]?.icon} {a.display_name}</option>)}
            </select>
            <input className="input text-sm mt-2" placeholder="/path" value={form.destination_path} onChange={e => setForm(f => ({ ...f, destination_path: e.target.value }))} />
          </div>
        </div>
        <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 mb-4 text-xs text-blue-700">
          Mirror mode streams all files from source to destination. Run manually or schedule it in the <strong>Scheduled Tasks</strong> tab.
        </div>
        <button className="btn-primary flex items-center gap-2" onClick={handleSync} disabled={syncMutation.isPending}>
          {syncMutation.isPending ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Plus className="w-4 h-4" />}
          Start Sync
        </button>
      </div>

      <div className="card">
        <div className="p-4 border-b border-slate-100">
          <h2 className="text-sm font-semibold text-slate-700">Sync History</h2>
        </div>
        {!transfers?.length ? (
          <div className="p-8 text-center text-sm text-slate-400">No sync tasks yet.</div>
        ) : (
          <div className="divide-y divide-slate-50">
            {transfers.map((t: any) => {
              const src = accts.find(a => a.id === t.source_account_id)
              const dst = accts.find(a => a.id === t.destination_account_id)
              const badge = { completed: 'bg-green-50 text-green-700', running: 'bg-blue-50 text-blue-700', failed: 'bg-red-50 text-red-600' }[t.status as string] || 'bg-slate-100 text-slate-600'
              return (
                <div key={t.id} className="flex items-center gap-3 px-4 py-3 text-sm">
                  <FolderSync className="w-4 h-4 text-blue-500 shrink-0" />
                  <span className="flex-1 text-slate-700 truncate">{src?.display_name} → {dst?.display_name}</span>
                  <span className={`badge ${badge}`}>{t.status}</span>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
