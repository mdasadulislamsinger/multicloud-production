import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, Repeat2, Shield, Zap, CalendarClock, FolderSync, HardDrive } from 'lucide-react'

const FEATURES = [
  { icon: ArrowRight, title: 'Cloud Transfer', desc: 'Move files between any two clouds instantly with streaming.' },
  { icon: Repeat2, title: 'Two-Way Sync', desc: 'Keep folders perfectly in sync across accounts.' },
  { icon: HardDrive, title: 'Cloud Backup', desc: 'Auto-backup your data to a secondary cloud provider.' },
  { icon: FolderSync, title: 'File Manager', desc: 'Browse, rename, move and delete across all your clouds.' },
  { icon: CalendarClock, title: 'Scheduling', desc: 'Automate transfers on daily, weekly, or custom schedules.' },
  { icon: Shield, title: 'Secure & Private', desc: 'Tokens encrypted at rest. Data streams directly between clouds.' },
]

const CLOUDS = ['Google Drive', 'OneDrive', 'Dropbox', 'Amazon S3', 'FTP / SFTP', 'Box', 'MEGA', 'Backblaze', 'Wasabi', 'pCloud']

const STATS = [
  ['30+', 'Cloud services'],
  ['1B+', 'Files transferred'],
  ['AES-256', 'Token encryption'],
  ['Open Source', 'Backend'],
]

export default function LandingPage() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-navy-800 font-sans">
      {/* Nav */}
      <nav className="sticky top-0 z-50 bg-navy-800/95 backdrop-blur border-b border-white/10 px-6 h-14 flex items-center">
        <CloudLogo />
        <div className="ml-auto flex items-center gap-4">
          <a href="#features" className="text-slate-400 hover:text-white text-sm transition-colors">Features</a>
          <a href="#clouds" className="text-slate-400 hover:text-white text-sm transition-colors">Clouds</a>
          <button onClick={() => navigate('/login')} className="bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-all active:scale-95">
            Get Started
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden flex flex-col items-center justify-center text-center px-6 py-28 min-h-[520px]">
        {/* Floating clouds bg */}
        <FloatingCloud className="absolute top-10 left-16 opacity-20 w-24" delay={0} />
        <FloatingCloud className="absolute top-20 right-20 opacity-15 w-20" delay={1.5} />
        <FloatingCloud className="absolute bottom-16 left-[10%] opacity-10 w-16" delay={0.8} />
        <FloatingCloud className="absolute bottom-24 right-[12%] opacity-15 w-20" delay={2} />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative z-10 max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 bg-blue-500/15 border border-blue-400/30 rounded-full px-4 py-1.5 mb-6">
            <Zap className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-blue-300 text-xs font-medium">Real cloud-to-cloud transfers — no storage limits</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-semibold text-white leading-tight mb-5">
            Transfer files between<br />
            <span className="text-blue-400">any cloud</span>, instantly
          </h1>
          <p className="text-slate-400 text-lg mb-8 leading-relaxed">
            Connect Google Drive, OneDrive, Dropbox, S3, FTP and more.<br />
            Stream files directly between clouds with real-time progress.
          </p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => navigate('/login')}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold px-7 py-3.5 rounded-xl transition-all active:scale-95 shadow-lg shadow-blue-900/40"
            >
              Start transferring free <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigate('/dashboard')}
              className="text-slate-400 hover:text-white text-sm px-4 py-3.5 rounded-xl transition-colors"
            >
              View dashboard →
            </button>
          </div>
        </motion.div>
      </section>

      {/* Stats */}
      <section className="bg-white/5 border-y border-white/10 py-10 px-6">
        <div className="max-w-3xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS.map(([val, label]) => (
            <div key={label} className="text-center">
              <div className="text-2xl font-semibold text-blue-400 mb-1">{val}</div>
              <div className="text-xs text-slate-500">{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-6 max-w-5xl mx-auto">
        <h2 className="text-center text-2xl font-semibold text-white mb-2">Everything you need</h2>
        <p className="text-center text-slate-500 mb-12 text-sm">Production-grade tools for managing all your clouds in one place</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map(({ icon: Icon, title, desc }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-white/5 hover:bg-white/8 border border-white/10 rounded-xl p-5 cursor-default transition-colors"
            >
              <div className="w-9 h-9 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4">
                <Icon className="w-5 h-5 text-blue-400" />
              </div>
              <h3 className="text-white font-medium mb-2 text-sm">{title}</h3>
              <p className="text-slate-500 text-xs leading-relaxed">{desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Cloud marquee */}
      <section id="clouds" className="py-14 overflow-hidden bg-white/3 border-y border-white/10">
        <h2 className="text-center text-lg font-medium text-white mb-8">Supported cloud services</h2>
        <div className="flex gap-3 animate-[scrollLeft_20s_linear_infinite] w-max">
          {[...CLOUDS, ...CLOUDS].map((name, i) => (
            <div key={i} className="flex items-center gap-2 bg-white/8 border border-white/10 rounded-lg px-4 py-2.5 whitespace-nowrap">
              <span className="text-xs text-slate-400">{name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 text-center">
        <h2 className="text-3xl font-semibold text-white mb-4">Ready to unify your clouds?</h2>
        <p className="text-slate-400 mb-8">Connect your accounts in minutes. No credit card required.</p>
        <button
          onClick={() => navigate('/login')}
          className="bg-blue-600 hover:bg-blue-500 text-white font-semibold px-8 py-4 rounded-xl transition-all active:scale-95 shadow-lg shadow-blue-900/40"
        >
          Get started free →
        </button>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8 px-6 text-center">
        <p className="text-xs text-slate-600">© 2025 MultiCloud. Open source. Built with FastAPI, React & real cloud APIs.</p>
      </footer>
    </div>
  )
}

function CloudLogo() {
  return (
    <div className="flex items-center gap-2">
      <svg width="30" height="22" viewBox="0 0 30 22">
        <ellipse cx="10" cy="17" rx="8" ry="4.5" fill="#4DA6FF" opacity=".9" />
        <ellipse cx="10" cy="13" rx="6" ry="4.5" fill="#80CCFF" />
        <ellipse cx="15" cy="11" rx="4.5" ry="3.5" fill="#fff" opacity=".9" />
        <ellipse cx="21" cy="15" rx="7" ry="4" fill="#4DA6FF" opacity=".85" />
        <ellipse cx="21" cy="11" rx="4.5" ry="3.5" fill="#80CCFF" />
        <ellipse cx="25" cy="9" rx="3.5" ry="3" fill="#fff" opacity=".85" />
      </svg>
      <span className="text-white font-medium text-sm">Multi<span className="text-blue-400">Cloud</span></span>
    </div>
  )
}

function FloatingCloud({ className, delay }: { className?: string; delay?: number }) {
  return (
    <motion.div
      className={className}
      animate={{ y: [0, -10, 0] }}
      transition={{ duration: 4, repeat: Infinity, delay, ease: 'easeInOut' }}
    >
      <svg viewBox="0 0 80 50" fill="none">
        <ellipse cx="35" cy="38" rx="32" ry="11" fill="#4DA6FF" />
        <ellipse cx="35" cy="27" rx="22" ry="17" fill="#80CCFF" />
        <ellipse cx="54" cy="22" rx="16" ry="13" fill="#B3DEFF" />
      </svg>
    </motion.div>
  )
}
