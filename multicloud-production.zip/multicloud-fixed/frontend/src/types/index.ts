export type CloudProvider =
  | 'google_drive'
  | 'onedrive'
  | 'dropbox'
  | 'box'
  | 's3'
  | 'ftp'
  | 'sftp'

export interface CloudAccount {
  id: string
  provider: CloudProvider
  display_name: string
  account_email?: string
  storage_used_bytes: number
  storage_total_bytes: number
  is_active: boolean
  created_at: string
}

export type TransferStatus =
  | 'pending'
  | 'running'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'cancelled'

export type TransferMode = 'copy' | 'move' | 'mirror'

export interface Transfer {
  id: string
  status: TransferStatus
  source_account_id: string
  destination_account_id: string
  source_path: string
  destination_path: string
  mode: TransferMode
  total_files: number
  transferred_files: number
  failed_files: number
  total_bytes: number
  transferred_bytes: number
  transfer_speed_bps: number
  created_at: string
  started_at?: string
  completed_at?: string
  error_message?: string
}

export interface TransferProgress {
  transfer_id: string
  status: TransferStatus
  percent: number
  transferred_files: number
  total_files: number
  failed_files: number
  transferred_bytes: number
  total_bytes: number
  speed_mbps: number
  eta_seconds?: number
  error_message?: string
}

export interface FileItem {
  id: string
  name: string
  path: string
  is_folder: boolean
  size?: number
  modified_at?: string
  mime_type?: string
}

export interface ScheduledTask {
  id: string
  name: string
  task_type: 'transfer' | 'sync' | 'backup'
  source_account_id: string
  destination_account_id: string
  source_path: string
  destination_path: string
  schedule_type: string
  is_active: boolean
  last_run_at?: string
  next_run_at?: string
  run_count: number
  created_at: string
}
