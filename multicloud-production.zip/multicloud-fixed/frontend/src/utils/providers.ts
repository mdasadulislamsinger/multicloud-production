import type { CloudProvider } from '@/types'

export const PROVIDER_META: Record<CloudProvider, { label: string; color: string; bg: string; icon: string }> = {
  google_drive: { label: 'Google Drive', color: '#1a73e8', bg: '#e8f0fe', icon: '📁' },
  onedrive:     { label: 'OneDrive',     color: '#0078d4', bg: '#ddf1ff', icon: '☁️' },
  dropbox:      { label: 'Dropbox',      color: '#0061ff', bg: '#e5efff', icon: '📦' },
  box:          { label: 'Box',          color: '#0061d5', bg: '#e3f0ff', icon: '🗃️' },
  s3:           { label: 'Amazon S3',    color: '#ff9900', bg: '#fff3e0', icon: '🪣' },
  ftp:          { label: 'FTP',          color: '#6b7280', bg: '#f3f4f6', icon: '🖥️' },
  sftp:         { label: 'SFTP',         color: '#374151', bg: '#f9fafb', icon: '🔒' },
}

export function formatBytes(bytes: number): string {
  if (!bytes) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`
}

export function formatSpeed(mbps: number): string {
  if (!mbps) return '—'
  if (mbps >= 1000) return `${(mbps / 1024).toFixed(1)} GB/s`
  if (mbps >= 1) return `${mbps.toFixed(1)} MB/s`
  return `${(mbps * 1024).toFixed(0)} KB/s`
}

export function formatEta(seconds?: number): string {
  if (!seconds) return '—'
  if (seconds < 60) return `${seconds}s`
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${seconds % 60}s`
  return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`
}
