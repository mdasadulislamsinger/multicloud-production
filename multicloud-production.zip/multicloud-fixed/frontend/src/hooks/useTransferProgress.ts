import { useEffect, useRef, useState, useCallback } from 'react'
import { transfersApi } from '@/services/api'
import type { TransferProgress } from '@/types'

export function useTransferProgress(transferId: string | null) {
  const [progress, setProgress] = useState<TransferProgress | null>(null)
  const [connected, setConnected] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)

  const connect = useCallback(() => {
    if (!transferId) return
    const url = transfersApi.wsUrl(transferId)
    const ws = new WebSocket(url)
    wsRef.current = ws

    ws.onopen = () => setConnected(true)

    ws.onmessage = (event) => {
      try {
        const data: TransferProgress = JSON.parse(event.data)
        setProgress(data)
        // Close when terminal state reached
        if (['completed', 'failed', 'cancelled'].includes(data.status)) {
          ws.close()
        }
      } catch {
        // ignore parse errors
      }
    }

    ws.onclose = () => setConnected(false)
    ws.onerror = () => setConnected(false)
  }, [transferId])

  useEffect(() => {
    connect()
    return () => {
      wsRef.current?.close()
    }
  }, [connect])

  return { progress, connected }
}
