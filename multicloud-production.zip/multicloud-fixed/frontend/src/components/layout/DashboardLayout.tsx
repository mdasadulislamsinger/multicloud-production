import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { ArrowLeftRight, FolderSync, Files, CalendarClock, Cloud, LogOut, User } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { motion } from 'framer-motion'

const NAV = [
  { to: '/dashboard', label: 'Transfer', icon: ArrowLeftRight, end: true },
  { to: '/dashboard/sync', label: 'Sync', icon: FolderSync },
  { to: '/dashboard/files', label: 'Files', icon: Files },
  { to: '/dashboard/tasks', label: 'Scheduled', icon: CalendarClock },
  { to: '/dashboard/accounts', label: 'Accounts', icon: Cloud },
]

export default function DashboardLayout() {
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top Nav */}
      <header className="bg-[#001F4D] border-b border-white/10 h-13 flex items-center px-5 gap-4 sticky top-0 z-40">
        <button onClick={() => navigate('/')} className="flex items-center gap-2 mr-4 shrink-0">
          <svg width="26" height="20" viewBox="0 0 26 20">
            <ellipse cx="9" cy="15" rx="7.5" ry="4" fill="#4DA6FF" opacity=".9" />
            <ellipse cx="9" cy="11" rx="5.5" ry="4" fill="#80CCFF" />
            <ellipse cx="14" cy="9.5" rx="4" ry="3.2" fill="#fff" opacity=".9" />
            <ellipse cx="19" cy="13" rx="6" ry="3.8" fill="#4DA6FF" opacity=".85" />
            <ellipse cx="19" cy="9.5" rx="4" ry="3" fill="#80CCFF" />
            <ellipse cx="22.5" cy="8" rx="3" ry="2.6" fill="#fff" opacity=".85" />
          </svg>
          <span className="text-white text-sm font-medium">Multi<span className="text-blue-400">Cloud</span></span>
        </button>

        {/* Nav tabs */}
        <nav className="flex gap-1">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-white/10'
                }`
              }
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <div className="flex items-center gap-2 text-slate-300 text-xs">
            <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-xs font-semibold text-white overflow-hidden">
              {user?.avatar_url ? (
                <img src={user.avatar_url} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <User className="w-4 h-4" />
              )}
            </div>
            <span className="hidden md:inline">{user?.name || user?.email}</span>
          </div>
          <button
            onClick={handleLogout}
            title="Sign out"
            className="text-slate-500 hover:text-slate-300 p-1.5 rounded-lg hover:bg-white/10 transition-all"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 p-5">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
        >
          <Outlet />
        </motion.div>
      </main>
    </div>
  )
}
