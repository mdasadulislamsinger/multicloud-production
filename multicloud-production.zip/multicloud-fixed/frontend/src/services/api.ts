import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_URL || '/api/v1'

export const api = axios.create({
  baseURL: API_BASE,
  withCredentials: false,
})

// Attach JWT access token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Refresh token on 401
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      const refreshToken = localStorage.getItem('refresh_token')
      if (!refreshToken) {
        localStorage.clear()
        window.location.href = '/login'
        return Promise.reject(error)
      }
      try {
        const res = await axios.post(`${API_BASE}/auth/refresh`, {
          refresh_token: refreshToken,
        })
        const { access_token, refresh_token } = res.data
        localStorage.setItem('access_token', access_token)
        localStorage.setItem('refresh_token', refresh_token)
        original.headers.Authorization = `Bearer ${access_token}`
        return api(original)
      } catch {
        localStorage.clear()
        window.location.href = '/login'
        return Promise.reject(error)
      }
    }
    return Promise.reject(error)
  }
)

// ─── Auth ──────────────────────────────────────────────────────────────────────

export const authApi = {
  getMe: () => api.get('/auth/me'),
  refresh: (refreshToken: string) =>
    api.post('/auth/refresh', { refresh_token: refreshToken }),
  googleLoginUrl: () => `${API_BASE}/auth/google`,
  microsoftLoginUrl: () => `${API_BASE}/auth/microsoft`,
}

// ─── Cloud Accounts ────────────────────────────────────────────────────────────

export const accountsApi = {
  list: () => api.get('/accounts/'),
  disconnect: (id: string) => api.delete(`/accounts/${id}`),
  connectGoogleDrive: () =>
    api.get('/accounts/google-drive/connect').then((r) => r.data.auth_url),
  connectOneDrive: () =>
    api.get('/accounts/onedrive/connect').then((r) => r.data.auth_url),
  connectDropbox: () =>
    api.get('/accounts/dropbox/connect').then((r) => r.data.auth_url),
  connectS3: (data: {
    display_name: string
    access_key_id: string
    secret_access_key: string
    region: string
    bucket_name?: string
  }) => api.post('/accounts/s3', data),
  connectFTP: (data: {
    display_name: string
    host: string
    port: number
    username: string
    password: string
    protocol: string
  }) => api.post('/accounts/ftp', data),
}

// ─── Files ────────────────────────────────────────────────────────────────────

export const filesApi = {
  list: (accountId: string, path: string) =>
    api.get(`/files/${accountId}/list`, { params: { path } }),
  delete: (accountId: string, path: string) =>
    api.delete(`/files/${accountId}/files`, { params: { path } }),
  rename: (accountId: string, path: string, newName: string) =>
    api.post(`/files/${accountId}/rename`, { new_name: newName }, { params: { path } }),
  move: (accountId: string, path: string, destinationPath: string) =>
    api.post(`/files/${accountId}/move`, { destination_path: destinationPath }, { params: { path } }),
  createFolder: (accountId: string, path: string) =>
    api.post(`/files/${accountId}/mkdir`, null, { params: { path } }),
}

// ─── Transfers ────────────────────────────────────────────────────────────────

export const transfersApi = {
  create: (data: {
    source_account_id: string
    destination_account_id: string
    source_path: string
    destination_path: string
    mode: string
  }) => api.post('/transfers/', data),
  list: (params?: { status?: string; limit?: number; offset?: number }) =>
    api.get('/transfers/', { params }),
  get: (id: string) => api.get(`/transfers/${id}`),
  pause: (id: string) => api.post(`/transfers/${id}/pause`),
  resume: (id: string) => api.post(`/transfers/${id}/resume`),
  cancel: (id: string) => api.post(`/transfers/${id}/cancel`),
  wsUrl: (id: string) => {
    const token = localStorage.getItem('access_token')
    const base = (import.meta.env.VITE_WS_URL || 'ws://localhost:8000/api/v1')
    return `${base}/transfers/ws/${id}?token=${token}`
  },
}

// ─── Scheduled Tasks ──────────────────────────────────────────────────────────

export const tasksApi = {
  create: (data: object) => api.post('/tasks/', data),
  list: () => api.get('/tasks/'),
  toggle: (id: string) => api.patch(`/tasks/${id}/toggle`),
  delete: (id: string) => api.delete(`/tasks/${id}`),
}
