# MultiCloud — Production-Ready Multi-Cloud File Transfer Platform

Transfer, sync, and back up files between **Google Drive**, **OneDrive**, **Dropbox**, **Amazon S3**, **FTP/SFTP**, and more.

## Architecture

```
multicloud/
├── frontend/          # React 18 + Vite + TailwindCSS
│   ├── src/
│   │   ├── pages/     # Transfer, Sync, Files, Tasks, Accounts, Landing, Login
│   │   ├── components/# DashboardLayout
│   │   ├── services/  # axios API client (api.ts)
│   │   ├── store/     # Zustand auth store
│   │   ├── hooks/     # useTransferProgress (WebSocket)
│   │   ├── utils/     # providers metadata + formatters
│   │   └── types/     # TypeScript interfaces
├── backend/           # FastAPI + SQLAlchemy + Celery
│   └── app/
│       ├── core/      # config, database, security, encryption
│       ├── models/    # User, CloudAccount, Transfer, ScheduledTask
│       ├── routers/   # auth, accounts, files, transfers, tasks, webhooks
│       ├── services/  # adapters (Google Drive, OneDrive, Dropbox, S3, FTP)
│       │              # transfer_engine, storage_quota, scheduler
│       └── workers/   # transfer_worker (Celery), beat_schedule
├── docker-compose.yml # Full stack: postgres, redis, api, worker, beat, frontend
├── .env.example       # Copy to .env and fill in values
└── railway.toml       # Railway/Render deployment config
```

## Quick Start (Docker)

```bash
# 1. Clone and copy env
cp .env.example .env

# 2. Fill in your OAuth credentials in .env (see section below)

# 3. Start everything
docker compose up --build

# Frontend: http://localhost:5173
# Backend API: http://localhost:8000
# API Docs: http://localhost:8000/docs
```

## Local Development (without Docker)

### Backend
```bash
cd backend
pip install -r requirements.txt

# Start PostgreSQL and Redis first, then:
uvicorn app.main:app --reload --port 8000

# Celery worker (separate terminal):
celery -A app.workers.transfer_worker.celery_app worker --loglevel=info

# Celery beat scheduler (separate terminal):
celery -A app.workers.beat_schedule.celery_app beat --loglevel=info
```

### Frontend
```bash
cd frontend
npm install
npm run dev
# http://localhost:5173
```

## Environment Variables

Copy `.env.example` to `.env` and fill in:

| Variable | Description |
|---|---|
| `SECRET_KEY` | Random 32+ char string for JWT signing |
| `ENCRYPTION_KEY` | Random 32+ char string for token encryption |
| `BACKEND_URL` | Your backend URL (e.g. `https://api.yourdomain.com`) |
| `FRONTEND_URL` | Your frontend URL (e.g. `https://yourdomain.com`) |
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `GOOGLE_CLIENT_ID/SECRET` | From Google Cloud Console |
| `MICROSOFT_CLIENT_ID/SECRET` | From Azure App Registration |
| `DROPBOX_APP_KEY/SECRET` | From Dropbox Developer Console |

## OAuth Setup

### Google (Login + Google Drive)
1. Go to [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
2. Create OAuth 2.0 credentials (Web Application)
3. Add redirect URIs:
   - `{BACKEND_URL}/api/v1/auth/google/callback`
   - `{BACKEND_URL}/api/v1/accounts/google-drive/callback`
4. Enable: Google Drive API, Google+ API

### Microsoft (Login + OneDrive)
1. Go to [Azure App Registrations](https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps)
2. Add redirect URIs:
   - `{BACKEND_URL}/api/v1/auth/microsoft/callback`
   - `{BACKEND_URL}/api/v1/accounts/onedrive/callback`
3. Add API permissions: `openid`, `email`, `profile`, `User.Read`, `Files.ReadWrite.All`, `offline_access`

### Dropbox
1. Go to [Dropbox Developer Apps](https://www.dropbox.com/developers/apps)
2. Add redirect URI: `{BACKEND_URL}/api/v1/accounts/dropbox/callback`
3. Add permissions: `files.content.read`, `files.content.write`, `account_info.read`

## API Endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/auth/google` | Start Google login |
| GET | `/api/v1/auth/microsoft` | Start Microsoft login |
| POST | `/api/v1/auth/refresh` | Refresh JWT tokens |
| GET | `/api/v1/auth/me` | Get current user |
| GET | `/api/v1/accounts/` | List connected cloud accounts |
| GET | `/api/v1/accounts/google-drive/connect` | Start Google Drive OAuth |
| GET | `/api/v1/accounts/onedrive/connect` | Start OneDrive OAuth |
| GET | `/api/v1/accounts/dropbox/connect` | Start Dropbox OAuth |
| POST | `/api/v1/accounts/s3` | Connect Amazon S3 |
| POST | `/api/v1/accounts/ftp` | Connect FTP/SFTP |
| DELETE | `/api/v1/accounts/{id}` | Disconnect account |
| GET | `/api/v1/files/{account_id}/list` | Browse files |
| DELETE | `/api/v1/files/{account_id}/files` | Delete file |
| POST | `/api/v1/transfers/` | Start transfer |
| GET | `/api/v1/transfers/` | List transfers |
| POST | `/api/v1/transfers/{id}/pause` | Pause transfer |
| POST | `/api/v1/transfers/{id}/resume` | Resume transfer |
| POST | `/api/v1/transfers/{id}/cancel` | Cancel transfer |
| WS | `/api/v1/transfers/ws/{id}?token=` | Real-time progress |
| GET | `/api/v1/tasks/` | List scheduled tasks |
| POST | `/api/v1/tasks/` | Create scheduled task |
| PATCH | `/api/v1/tasks/{id}/toggle` | Enable/disable task |
| DELETE | `/api/v1/tasks/{id}` | Delete task |

## Production Deployment

### Backend (Railway / Render)
- Point to `/backend` directory
- Build: `pip install -r requirements.txt`
- Start: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
- Deploy Celery worker as a separate service with: `celery -A app.workers.transfer_worker.celery_app worker --loglevel=info`
- Deploy Celery beat as a separate service with: `celery -A app.workers.beat_schedule.celery_app beat --loglevel=info`

### Frontend (Vercel / Netlify)
- Point to `/frontend` directory
- Build: `npm run build`
- Output: `dist/`
- Set `VITE_API_URL` and `VITE_WS_URL` to your backend URL

## Supported Cloud Providers

| Provider | Auth | List | Download | Upload | Delete | Rename | Move |
|---|---|---|---|---|---|---|---|
| Google Drive | OAuth | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| OneDrive | OAuth | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Dropbox | OAuth | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Amazon S3 | Key/Secret | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| FTP | Credentials | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| SFTP | Credentials | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
