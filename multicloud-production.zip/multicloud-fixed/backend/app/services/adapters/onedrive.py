"""
OneDrive adapter using Microsoft Graph API.
"""
import httpx
from app.services.cloud_adapter import BaseCloudAdapter, CloudFileItem


class OneDriveAdapter(BaseCloudAdapter):
    BASE = "https://graph.microsoft.com/v1.0/me/drive"

    def __init__(self, access_token: str, account=None):
        self.access_token = access_token
        self.account = account
        self._headers = {"Authorization": f"Bearer {access_token}"}

    def _path_url(self, path: str) -> str:
        if path in ("/", ""):
            return f"{self.BASE}/root/children"
        encoded = path.strip("/")
        return f"{self.BASE}/root:/{encoded}:/children"

    async def list_files(self, path: str) -> list[dict]:
        files = []
        url = self._path_url(path)
        async with httpx.AsyncClient() as client:
            while url:
                resp = await client.get(url, headers=self._headers)
                data = resp.json()
                for item in data.get("value", []):
                    is_folder = "folder" in item
                    files.append(CloudFileItem(
                        id=item["id"],
                        name=item["name"],
                        path=f"{path.rstrip('/')}/{item['name']}",
                        is_folder=is_folder,
                        size=item.get("size", 0) if not is_folder else 0,
                        modified_at=item.get("lastModifiedDateTime"),
                        mime_type=item.get("file", {}).get("mimeType"),
                    ).dict())
                url = data.get("@odata.nextLink")
        return files

    async def download_stream(self, path: str):
        """path = item ID"""
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.BASE}/items/{path}",
                params={"select": "id,@microsoft.graph.downloadUrl"},
                headers=self._headers,
            )
            download_url = resp.json().get("@microsoft.graph.downloadUrl")
            async with client.stream("GET", download_url) as stream:
                async for chunk in stream.aiter_bytes(1024 * 1024):
                    yield chunk

    async def upload_stream(self, path: str, stream, size: int):
        """Use OneDrive large file upload session for files > 4MB."""
        filename = path.rsplit("/", 1)[-1]
        parent = path.rsplit("/", 1)[0] if "/" in path else "/"
        parent_encoded = parent.strip("/")
        item_path = f"root:/{parent_encoded}/{filename}:" if parent_encoded else f"root:/{filename}:"

        async with httpx.AsyncClient(timeout=600) as client:
            # Create upload session
            session_resp = await client.post(
                f"{self.BASE}/{item_path}/createUploadSession",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"item": {"@microsoft.graph.conflictBehavior": "replace", "name": filename}},
            )
            upload_url = session_resp.json()["uploadUrl"]

            # Upload in 10MB chunks
            chunk_size = 10 * 1024 * 1024
            offset = 0
            async for chunk in stream:
                end = min(offset + len(chunk) - 1, size - 1)
                await client.put(
                    upload_url,
                    content=chunk,
                    headers={"Content-Range": f"bytes {offset}-{end}/{size}"},
                )
                offset += len(chunk)

    async def delete(self, path: str):
        """path = item ID"""
        async with httpx.AsyncClient() as client:
            await client.delete(f"{self.BASE}/items/{path}", headers=self._headers)

    async def rename(self, path: str, new_name: str):
        async with httpx.AsyncClient() as client:
            await client.patch(
                f"{self.BASE}/items/{path}",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"name": new_name},
            )

    async def move(self, source_path: str, destination_path: str):
        # First get destination folder ID
        dest_encoded = destination_path.strip("/")
        async with httpx.AsyncClient() as client:
            dest_resp = await client.get(
                f"{self.BASE}/root:/{dest_encoded}",
                params={"select": "id"},
                headers=self._headers,
            )
            dest_id = dest_resp.json()["id"]
            await client.patch(
                f"{self.BASE}/items/{source_path}",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"parentReference": {"id": dest_id}},
            )

    async def create_folder(self, path: str):
        parts = path.rsplit("/", 1)
        parent_path = parts[0] if len(parts) > 1 else "/"
        folder_name = parts[-1]
        parent_encoded = parent_path.strip("/")
        url = (f"{self.BASE}/root:/{parent_encoded}:/children"
               if parent_encoded else f"{self.BASE}/root/children")
        async with httpx.AsyncClient() as client:
            await client.post(
                url,
                headers={**self._headers, "Content-Type": "application/json"},
                json={"name": folder_name, "folder": {}, "@microsoft.graph.conflictBehavior": "rename"},
            )

    async def get_file_checksum(self, path: str) -> str:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.BASE}/items/{path}",
                params={"select": "file"},
                headers=self._headers,
            )
            hashes = resp.json().get("file", {}).get("hashes", {})
            return hashes.get("sha256Hash") or hashes.get("quickXorHash") or ""
