"""
Google Drive adapter using the Google Drive REST API v3.
"""
import hashlib
import httpx
from app.services.cloud_adapter import BaseCloudAdapter, CloudFileItem


class GoogleDriveAdapter(BaseCloudAdapter):
    BASE = "https://www.googleapis.com/drive/v3"
    UPLOAD_BASE = "https://www.googleapis.com/upload/drive/v3"

    def __init__(self, access_token: str, account=None):
        self.access_token = access_token
        self.account = account
        self._headers = {"Authorization": f"Bearer {access_token}"}

    async def _ensure_fresh_token(self):
        """Refresh token if expired."""
        from datetime import datetime, timezone
        if self.account and self.account.token_expires_at:
            if self.account.token_expires_at < datetime.now(timezone.utc):
                await self._refresh_access_token()

    async def _refresh_access_token(self):
        from app.core.config import settings
        from app.core.encryption import decrypt_token, encrypt_token
        from app.core.database import AsyncSessionLocal
        from sqlalchemy import select
        from app.models.cloud_account import CloudAccount

        refresh_token = decrypt_token(self.account.refresh_token_encrypted)
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "refresh_token": refresh_token,
                    "client_id": settings.GOOGLE_CLIENT_ID,
                    "client_secret": settings.GOOGLE_CLIENT_SECRET,
                    "grant_type": "refresh_token",
                },
            )
            data = resp.json()

        self.access_token = data["access_token"]
        self._headers = {"Authorization": f"Bearer {self.access_token}"}

        async with AsyncSessionLocal() as db:
            result = await db.execute(select(CloudAccount).where(CloudAccount.id == self.account.id))
            acc = result.scalar_one_or_none()
            if acc:
                acc.access_token_encrypted = encrypt_token(self.access_token)
                await db.commit()

    async def _get_folder_id(self, path: str) -> str:
        """Resolve a path like /Documents/Photos to a folder ID."""
        if path in ("/", ""):
            return "root"
        parts = [p for p in path.strip("/").split("/") if p]
        current_id = "root"
        async with httpx.AsyncClient() as client:
            for part in parts:
                params = {
                    "q": f"'{current_id}' in parents and name='{part}' and mimeType='application/vnd.google-apps.folder' and trashed=false",
                    "fields": "files(id,name)",
                }
                resp = await client.get(f"{self.BASE}/files", params=params, headers=self._headers)
                files = resp.json().get("files", [])
                if not files:
                    raise FileNotFoundError(f"Folder not found: {part}")
                current_id = files[0]["id"]
        return current_id

    async def list_files(self, path: str) -> list[dict]:
        await self._ensure_fresh_token()
        folder_id = await self._get_folder_id(path)
        files = []
        page_token = None
        async with httpx.AsyncClient() as client:
            while True:
                params = {
                    "q": f"'{folder_id}' in parents and trashed=false",
                    "fields": "nextPageToken,files(id,name,mimeType,size,modifiedTime)",
                    "pageSize": 100,
                }
                if page_token:
                    params["pageToken"] = page_token
                resp = await client.get(f"{self.BASE}/files", params=params, headers=self._headers)
                data = resp.json()
                for f in data.get("files", []):
                    is_folder = f["mimeType"] == "application/vnd.google-apps.folder"
                    files.append(CloudFileItem(
                        id=f["id"],
                        name=f["name"],
                        path=f"{path.rstrip('/')}/{f['name']}",
                        is_folder=is_folder,
                        size=int(f.get("size", 0)) if not is_folder else 0,
                        modified_at=f.get("modifiedTime"),
                        mime_type=f.get("mimeType"),
                    ).dict())
                page_token = data.get("nextPageToken")
                if not page_token:
                    break
        return files

    async def download_stream(self, path: str):
        """Returns an async generator of bytes for the file at path."""
        await self._ensure_fresh_token()
        # path here is actually a file ID in Google Drive
        file_id = path  # We use file IDs directly for downloads
        async with httpx.AsyncClient() as client:
            async with client.stream(
                "GET",
                f"{self.BASE}/files/{file_id}?alt=media",
                headers=self._headers,
            ) as response:
                async for chunk in response.aiter_bytes(chunk_size=1024 * 1024):
                    yield chunk

    async def upload_stream(self, path: str, stream, size: int):
        """Upload using Google Drive resumable upload API."""
        await self._ensure_fresh_token()
        # Extract filename and parent folder
        parts = path.rsplit("/", 1)
        parent_path = parts[0] if len(parts) > 1 else "/"
        filename = parts[-1]

        parent_id = await self._get_folder_id(parent_path)

        # Initiate resumable upload
        async with httpx.AsyncClient(timeout=300) as client:
            init_resp = await client.post(
                f"{self.UPLOAD_BASE}/files?uploadType=resumable",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"name": filename, "parents": [parent_id]},
            )
            upload_url = init_resp.headers["Location"]

            # Stream upload in 8MB chunks
            chunk_size = 8 * 1024 * 1024
            offset = 0
            async for chunk in stream:
                end = offset + len(chunk) - 1
                resp = await client.put(
                    upload_url,
                    content=chunk,
                    headers={
                        "Content-Length": str(len(chunk)),
                        "Content-Range": f"bytes {offset}-{end}/{size}",
                    },
                )
                offset += len(chunk)
                if resp.status_code not in (200, 201, 308):
                    raise RuntimeError(f"Upload chunk failed: {resp.status_code}")

    async def delete(self, path: str):
        await self._ensure_fresh_token()
        # path = file_id
        async with httpx.AsyncClient() as client:
            await client.delete(f"{self.BASE}/files/{path}", headers=self._headers)

    async def rename(self, path: str, new_name: str):
        await self._ensure_fresh_token()
        async with httpx.AsyncClient() as client:
            await client.patch(
                f"{self.BASE}/files/{path}",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"name": new_name},
            )

    async def move(self, source_path: str, destination_path: str):
        await self._ensure_fresh_token()
        new_parent_id = await self._get_folder_id(destination_path)
        async with httpx.AsyncClient() as client:
            # Get current parents
            resp = await client.get(
                f"{self.BASE}/files/{source_path}",
                params={"fields": "parents"},
                headers=self._headers,
            )
            old_parents = ",".join(resp.json().get("parents", []))
            await client.patch(
                f"{self.BASE}/files/{source_path}",
                params={"addParents": new_parent_id, "removeParents": old_parents, "fields": "id"},
                headers=self._headers,
            )

    async def create_folder(self, path: str):
        await self._ensure_fresh_token()
        parts = path.rsplit("/", 1)
        parent_path = parts[0] if len(parts) > 1 else "/"
        folder_name = parts[-1]
        parent_id = await self._get_folder_id(parent_path)

        async with httpx.AsyncClient() as client:
            await client.post(
                f"{self.BASE}/files",
                headers={**self._headers, "Content-Type": "application/json"},
                json={
                    "name": folder_name,
                    "mimeType": "application/vnd.google-apps.folder",
                    "parents": [parent_id],
                },
            )

    async def get_file_checksum(self, path: str) -> str:
        await self._ensure_fresh_token()
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.BASE}/files/{path}",
                params={"fields": "md5Checksum,sha256Checksum"},
                headers=self._headers,
            )
            data = resp.json()
            return data.get("md5Checksum") or data.get("sha256Checksum") or ""
