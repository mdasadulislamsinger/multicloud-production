"""
Dropbox adapter using Dropbox API v2.
"""
import httpx
from app.services.cloud_adapter import BaseCloudAdapter, CloudFileItem


class DropboxAdapter(BaseCloudAdapter):
    API = "https://api.dropboxapi.com/2"
    CONTENT_API = "https://content.dropboxapi.com/2"

    def __init__(self, access_token: str):
        self.access_token = access_token
        self._headers = {"Authorization": f"Bearer {access_token}"}

    async def list_files(self, path: str) -> list[dict]:
        dbx_path = "" if path == "/" else path
        files = []
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.API}/files/list_folder",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"path": dbx_path, "recursive": False, "limit": 200},
            )
            data = resp.json()
            while True:
                for entry in data.get("entries", []):
                    is_folder = entry[".tag"] == "folder"
                    files.append(CloudFileItem(
                        id=entry.get("id", entry["path_display"]),
                        name=entry["name"],
                        path=entry["path_display"],
                        is_folder=is_folder,
                        size=entry.get("size", 0) if not is_folder else 0,
                        modified_at=entry.get("server_modified"),
                    ).dict())
                if not data.get("has_more"):
                    break
                resp = await client.post(
                    f"{self.API}/files/list_folder/continue",
                    headers={**self._headers, "Content-Type": "application/json"},
                    json={"cursor": data["cursor"]},
                )
                data = resp.json()
        return files

    async def download_stream(self, path: str):
        import json
        async with httpx.AsyncClient() as client:
            async with client.stream(
                "POST",
                f"{self.CONTENT_API}/files/download",
                headers={
                    **self._headers,
                    "Dropbox-API-Arg": json.dumps({"path": path}),
                },
            ) as resp:
                async for chunk in resp.aiter_bytes(1024 * 1024):
                    yield chunk

    async def upload_stream(self, path: str, stream, size: int):
        """Use Dropbox upload sessions for files > 150MB, simple upload otherwise."""
        import json
        if size <= 150 * 1024 * 1024:
            # Simple upload
            content = b""
            async for chunk in stream:
                content += chunk
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{self.CONTENT_API}/files/upload",
                    headers={
                        **self._headers,
                        "Content-Type": "application/octet-stream",
                        "Dropbox-API-Arg": json.dumps({"path": path, "mode": "overwrite", "autorename": False}),
                    },
                    content=content,
                )
        else:
            # Upload session
            chunk_size = 50 * 1024 * 1024
            session_id = None
            offset = 0
            async with httpx.AsyncClient(timeout=600) as client:
                async for chunk in stream:
                    if session_id is None:
                        resp = await client.post(
                            f"{self.CONTENT_API}/files/upload_session/start",
                            headers={
                                **self._headers,
                                "Content-Type": "application/octet-stream",
                                "Dropbox-API-Arg": json.dumps({"close": False}),
                            },
                            content=chunk,
                        )
                        session_id = resp.json()["session_id"]
                    else:
                        is_last = (offset + len(chunk) >= size)
                        if is_last:
                            await client.post(
                                f"{self.CONTENT_API}/files/upload_session/finish",
                                headers={
                                    **self._headers,
                                    "Content-Type": "application/octet-stream",
                                    "Dropbox-API-Arg": json.dumps({
                                        "cursor": {"session_id": session_id, "offset": offset},
                                        "commit": {"path": path, "mode": "overwrite"},
                                    }),
                                },
                                content=chunk,
                            )
                        else:
                            await client.post(
                                f"{self.CONTENT_API}/files/upload_session/append_v2",
                                headers={
                                    **self._headers,
                                    "Content-Type": "application/octet-stream",
                                    "Dropbox-API-Arg": json.dumps({
                                        "cursor": {"session_id": session_id, "offset": offset},
                                        "close": False,
                                    }),
                                },
                                content=chunk,
                            )
                    offset += len(chunk)

    async def delete(self, path: str):
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{self.API}/files/delete_v2",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"path": path},
            )

    async def rename(self, path: str, new_name: str):
        parent = path.rsplit("/", 1)[0] or "/"
        new_path = f"{parent}/{new_name}"
        await self.move(path, new_path)

    async def move(self, source_path: str, destination_path: str):
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{self.API}/files/move_v2",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"from_path": source_path, "to_path": destination_path, "autorename": False},
            )

    async def create_folder(self, path: str):
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{self.API}/files/create_folder_v2",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"path": path, "autorename": False},
            )

    async def get_file_checksum(self, path: str) -> str:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.API}/files/get_metadata",
                headers={**self._headers, "Content-Type": "application/json"},
                json={"path": path, "include_media_info": False},
            )
            return resp.json().get("content_hash", "")
