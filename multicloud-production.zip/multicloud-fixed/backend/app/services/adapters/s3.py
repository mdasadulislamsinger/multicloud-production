"""
Amazon S3 adapter using aioboto3.
"""
import aioboto3
from app.services.cloud_adapter import BaseCloudAdapter, CloudFileItem


class S3Adapter(BaseCloudAdapter):
    def __init__(self, creds: dict):
        self.creds = creds
        self.session = aioboto3.Session(
            aws_access_key_id=creds["access_key_id"],
            aws_secret_access_key=creds["secret_access_key"],
            region_name=creds.get("region", "us-east-1"),
        )
        self.bucket = creds.get("bucket_name", "")

    async def list_files(self, path: str) -> list[dict]:
        prefix = path.lstrip("/")
        if prefix and not prefix.endswith("/"):
            prefix += "/"
        files = []
        async with self.session.client("s3") as s3:
            paginator = s3.get_paginator("list_objects_v2")
            async for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix, Delimiter="/"):
                # Folders (common prefixes)
                for cp in page.get("CommonPrefixes", []):
                    name = cp["Prefix"].rstrip("/").rsplit("/", 1)[-1]
                    files.append(CloudFileItem(
                        id=cp["Prefix"], name=name, path="/" + cp["Prefix"],
                        is_folder=True,
                    ).dict())
                # Files
                for obj in page.get("Contents", []):
                    if obj["Key"] == prefix:
                        continue
                    name = obj["Key"].rsplit("/", 1)[-1]
                    files.append(CloudFileItem(
                        id=obj["Key"], name=name, path="/" + obj["Key"],
                        is_folder=False,
                        size=obj["Size"],
                        modified_at=obj["LastModified"].isoformat(),
                    ).dict())
        return files

    async def download_stream(self, path: str):
        key = path.lstrip("/")
        async with self.session.client("s3") as s3:
            resp = await s3.get_object(Bucket=self.bucket, Key=key)
            async for chunk in resp["Body"].iter_chunks(1024 * 1024):
                yield chunk

    async def upload_stream(self, path: str, stream, size: int):
        key = path.lstrip("/")
        async with self.session.client("s3") as s3:
            # Multipart upload for large files
            mpu = await s3.create_multipart_upload(Bucket=self.bucket, Key=key)
            upload_id = mpu["UploadId"]
            parts = []
            part_number = 1
            buffer = b""
            try:
                async for chunk in stream:
                    buffer += chunk
                    if len(buffer) >= 5 * 1024 * 1024:  # 5MB minimum part size
                        part = await s3.upload_part(
                            Bucket=self.bucket, Key=key,
                            PartNumber=part_number, UploadId=upload_id,
                            Body=buffer,
                        )
                        parts.append({"PartNumber": part_number, "ETag": part["ETag"]})
                        part_number += 1
                        buffer = b""
                # Upload final chunk
                if buffer:
                    part = await s3.upload_part(
                        Bucket=self.bucket, Key=key,
                        PartNumber=part_number, UploadId=upload_id,
                        Body=buffer,
                    )
                    parts.append({"PartNumber": part_number, "ETag": part["ETag"]})
                await s3.complete_multipart_upload(
                    Bucket=self.bucket, Key=key, UploadId=upload_id,
                    MultipartUpload={"Parts": parts},
                )
            except Exception:
                await s3.abort_multipart_upload(Bucket=self.bucket, Key=key, UploadId=upload_id)
                raise

    async def delete(self, path: str):
        key = path.lstrip("/")
        async with self.session.client("s3") as s3:
            await s3.delete_object(Bucket=self.bucket, Key=key)

    async def rename(self, path: str, new_name: str):
        parent = path.rsplit("/", 1)[0] if "/" in path else "/"
        new_path = f"{parent}/{new_name}"
        await self.move(path, new_path)

    async def move(self, source_path: str, destination_path: str):
        src_key = source_path.lstrip("/")
        dst_key = destination_path.lstrip("/")
        async with self.session.client("s3") as s3:
            await s3.copy_object(
                Bucket=self.bucket, Key=dst_key,
                CopySource={"Bucket": self.bucket, "Key": src_key},
            )
            await s3.delete_object(Bucket=self.bucket, Key=src_key)

    async def create_folder(self, path: str):
        key = path.lstrip("/").rstrip("/") + "/"
        async with self.session.client("s3") as s3:
            await s3.put_object(Bucket=self.bucket, Key=key, Body=b"")

    async def get_file_checksum(self, path: str) -> str:
        key = path.lstrip("/")
        async with self.session.client("s3") as s3:
            resp = await s3.head_object(Bucket=self.bucket, Key=key)
            return resp.get("ETag", "").strip('"')
