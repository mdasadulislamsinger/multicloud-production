"""
FTP/SFTP adapter using aioftp and asyncssh.
"""
from app.services.cloud_adapter import BaseCloudAdapter, CloudFileItem


class FTPAdapter(BaseCloudAdapter):
    def __init__(self, creds: dict):
        self.creds = creds
        self.protocol = creds.get("protocol", "ftp")
        self.host = creds["host"]
        self.port = int(creds.get("port", 22 if self.protocol == "sftp" else 21))
        self.username = creds["username"]
        self.password = creds["password"]

    async def list_files(self, path: str) -> list[dict]:
        if self.protocol == "sftp":
            return await self._sftp_list(path)
        return await self._ftp_list(path)

    async def _sftp_list(self, path: str) -> list[dict]:
        import asyncssh
        async with asyncssh.connect(
            self.host, port=self.port, username=self.username,
            password=self.password, known_hosts=None
        ) as conn:
            async with conn.start_sftp_client() as sftp:
                entries = await sftp.readdir(path)
                files = []
                for entry in entries:
                    if entry.filename in (".", ".."):
                        continue
                    full_path = f"{path.rstrip('/')}/{entry.filename}"
                    is_folder = entry.attrs.type == asyncssh.FILEXFER_TYPE_DIRECTORY
                    files.append(CloudFileItem(
                        id=full_path, name=entry.filename, path=full_path,
                        is_folder=is_folder,
                        size=entry.attrs.size or 0 if not is_folder else 0,
                    ).dict())
                return files

    async def _ftp_list(self, path: str) -> list[dict]:
        import aioftp
        async with aioftp.Client.context(self.host, port=self.port,
                                          user=self.username, password=self.password) as client:
            files = []
            async for entry_path, info in client.list(path, recursive=False):
                name = str(entry_path).rsplit("/", 1)[-1]
                is_folder = info.get("type") == "dir"
                files.append(CloudFileItem(
                    id=str(entry_path), name=name, path=str(entry_path),
                    is_folder=is_folder,
                    size=int(info.get("size", 0)) if not is_folder else 0,
                    modified_at=info.get("modify"),
                ).dict())
            return files

    async def download_stream(self, path: str):
        if self.protocol == "sftp":
            async for chunk in self._sftp_download(path):
                yield chunk
        else:
            async for chunk in self._ftp_download(path):
                yield chunk

    async def _sftp_download(self, path: str):
        import asyncssh
        async with asyncssh.connect(
            self.host, port=self.port, username=self.username,
            password=self.password, known_hosts=None
        ) as conn:
            async with conn.start_sftp_client() as sftp:
                async with sftp.open(path, "rb") as f:
                    while True:
                        chunk = await f.read(1024 * 1024)
                        if not chunk:
                            break
                        yield chunk

    async def _ftp_download(self, path: str):
        import aioftp
        async with aioftp.Client.context(self.host, port=self.port,
                                          user=self.username, password=self.password) as client:
            async with client.download_stream(path) as stream:
                async for block in stream.iter_by_block(1024 * 1024):
                    yield block

    async def upload_stream(self, path: str, stream, size: int):
        if self.protocol == "sftp":
            await self._sftp_upload(path, stream)
        else:
            await self._ftp_upload(path, stream)

    async def _sftp_upload(self, path: str, stream):
        import asyncssh
        async with asyncssh.connect(
            self.host, port=self.port, username=self.username,
            password=self.password, known_hosts=None
        ) as conn:
            async with conn.start_sftp_client() as sftp:
                async with sftp.open(path, "wb") as f:
                    async for chunk in stream:
                        await f.write(chunk)

    async def _ftp_upload(self, path: str, stream):
        import aioftp
        content = b""
        async for chunk in stream:
            content += chunk
        async with aioftp.Client.context(self.host, port=self.port,
                                          user=self.username, password=self.password) as client:
            async with client.upload_stream(path) as upload:
                await upload.write(content)

    async def delete(self, path: str):
        if self.protocol == "sftp":
            import asyncssh
            async with asyncssh.connect(
                self.host, port=self.port, username=self.username,
                password=self.password, known_hosts=None
            ) as conn:
                async with conn.start_sftp_client() as sftp:
                    await sftp.unlink(path)
        else:
            import aioftp
            async with aioftp.Client.context(self.host, port=self.port,
                                              user=self.username, password=self.password) as client:
                await client.remove(path)

    async def rename(self, path: str, new_name: str):
        parent = path.rsplit("/", 1)[0] if "/" in path else "/"
        new_path = f"{parent}/{new_name}"
        await self.move(path, new_path)

    async def move(self, source_path: str, destination_path: str):
        if self.protocol == "sftp":
            import asyncssh
            async with asyncssh.connect(
                self.host, port=self.port, username=self.username,
                password=self.password, known_hosts=None
            ) as conn:
                async with conn.start_sftp_client() as sftp:
                    await sftp.rename(source_path, destination_path)
        else:
            import aioftp
            async with aioftp.Client.context(self.host, port=self.port,
                                              user=self.username, password=self.password) as client:
                await client.rename(source_path, destination_path)

    async def create_folder(self, path: str):
        if self.protocol == "sftp":
            import asyncssh
            async with asyncssh.connect(
                self.host, port=self.port, username=self.username,
                password=self.password, known_hosts=None
            ) as conn:
                async with conn.start_sftp_client() as sftp:
                    await sftp.mkdir(path)
        else:
            import aioftp
            async with aioftp.Client.context(self.host, port=self.port,
                                              user=self.username, password=self.password) as client:
                await client.make_directory(path)

    async def get_file_checksum(self, path: str) -> str:
        """FTP/SFTP don't provide standard checksums — compute on download."""
        import hashlib
        md5 = hashlib.md5()
        async for chunk in self.download_stream(path):
            md5.update(chunk)
        return md5.hexdigest()
