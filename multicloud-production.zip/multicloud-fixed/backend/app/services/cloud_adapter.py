"""
Cloud adapter factory — returns the correct adapter for a CloudAccount.
"""
import json
from abc import ABC, abstractmethod
from typing import Any
from app.models.cloud_account import CloudAccount, CloudProvider
from app.core.encryption import decrypt_token


class CloudFileItem:
    def __init__(self, id: str, name: str, path: str, is_folder: bool,
                 size: int = 0, modified_at: str = None, mime_type: str = None):
        self.id = id
        self.name = name
        self.path = path
        self.is_folder = is_folder
        self.size = size
        self.modified_at = modified_at
        self.mime_type = mime_type

    def dict(self):
        return {
            "id": self.id, "name": self.name, "path": self.path,
            "is_folder": self.is_folder, "size": self.size,
            "modified_at": self.modified_at, "mime_type": self.mime_type,
        }


class BaseCloudAdapter(ABC):
    @abstractmethod
    async def list_files(self, path: str) -> list[dict]: ...
    @abstractmethod
    async def download_stream(self, path: str): ...
    @abstractmethod
    async def upload_stream(self, path: str, stream, size: int): ...
    @abstractmethod
    async def delete(self, path: str): ...
    @abstractmethod
    async def rename(self, path: str, new_name: str): ...
    @abstractmethod
    async def move(self, source_path: str, destination_path: str): ...
    @abstractmethod
    async def create_folder(self, path: str): ...
    @abstractmethod
    async def get_file_checksum(self, path: str) -> str: ...


async def get_adapter(account: CloudAccount) -> BaseCloudAdapter:
    """Return the appropriate adapter for a cloud account."""
    if account.provider == CloudProvider.GOOGLE_DRIVE:
        from app.services.adapters.google_drive import GoogleDriveAdapter
        access_token = decrypt_token(account.access_token_encrypted)
        return GoogleDriveAdapter(access_token, account)

    elif account.provider == CloudProvider.ONEDRIVE:
        from app.services.adapters.onedrive import OneDriveAdapter
        access_token = decrypt_token(account.access_token_encrypted)
        return OneDriveAdapter(access_token, account)

    elif account.provider == CloudProvider.DROPBOX:
        from app.services.adapters.dropbox import DropboxAdapter
        access_token = decrypt_token(account.access_token_encrypted)
        return DropboxAdapter(access_token)

    elif account.provider == CloudProvider.S3:
        from app.services.adapters.s3 import S3Adapter
        creds = json.loads(decrypt_token(account.credentials_encrypted))
        return S3Adapter(creds)

    elif account.provider in (CloudProvider.FTP, CloudProvider.SFTP):
        from app.services.adapters.ftp import FTPAdapter
        creds = json.loads(decrypt_token(account.credentials_encrypted))
        return FTPAdapter(creds)

    else:
        raise ValueError(f"Unsupported provider: {account.provider}")
