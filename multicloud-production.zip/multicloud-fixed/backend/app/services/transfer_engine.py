"""
Transfer engine: streams files from source cloud to destination cloud.
Supports chunked transfers, progress tracking, retry, and checksum verification.
"""
import asyncio
import hashlib
import logging
import time
from typing import AsyncGenerator, Callable, Optional

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds


async def stream_transfer(
    source_adapter,
    dest_adapter,
    source_path: str,
    dest_path: str,
    file_size: int,
    on_progress: Optional[Callable] = None,
    verify_checksum: bool = True,
) -> dict:
    """
    Transfer a single file from source to destination.
    Streams in chunks: source → memory → destination.
    Returns transfer result dict.
    """
    last_error = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            result = await _attempt_transfer(
                source_adapter, dest_adapter,
                source_path, dest_path, file_size,
                on_progress, verify_checksum,
            )
            return result
        except Exception as e:
            last_error = e
            logger.warning(f"Transfer attempt {attempt}/{MAX_RETRIES} failed for {source_path}: {e}")
            if attempt < MAX_RETRIES:
                await asyncio.sleep(RETRY_DELAY * attempt)

    return {"success": False, "error": str(last_error)}


async def _attempt_transfer(
    source_adapter,
    dest_adapter,
    source_path: str,
    dest_path: str,
    file_size: int,
    on_progress: Optional[Callable],
    verify_checksum: bool,
) -> dict:
    src_hash = hashlib.sha256()
    transferred_bytes = 0
    start_time = time.monotonic()

    # Collect all chunks first to calculate progress correctly
    chunks = []
    async for chunk in source_adapter.download_stream(source_path):
        src_hash.update(chunk)
        chunks.append(chunk)
        transferred_bytes += len(chunk)
        elapsed = time.monotonic() - start_time
        speed_bps = transferred_bytes / elapsed if elapsed > 0 else 0
        if on_progress:
            await on_progress(len(chunk), file_size, speed_bps)

    # Create async generator from collected chunks for upload
    async def chunk_generator() -> AsyncGenerator[bytes, None]:
        for chunk in chunks:
            yield chunk

    await dest_adapter.upload_stream(dest_path, chunk_generator(), file_size or transferred_bytes)

    result = {
        "success": True,
        "transferred_bytes": transferred_bytes,
        "source_checksum": src_hash.hexdigest(),
    }

    if verify_checksum:
        try:
            dest_checksum = await dest_adapter.get_file_checksum(dest_path)
            result["destination_checksum"] = dest_checksum
            result["checksum_verified"] = bool(dest_checksum)
        except Exception as e:
            logger.warning(f"Checksum verification failed for {dest_path}: {e}")
            result["checksum_verified"] = False

    return result


async def collect_all_files(adapter, path: str, recursive: bool = True) -> list[dict]:
    """
    Recursively collect all files under a path.
    Returns list of file metadata dicts.
    """
    all_files = []
    queue = [path]
    while queue:
        current = queue.pop(0)
        try:
            items = await adapter.list_files(current)
        except Exception as e:
            logger.warning(f"Failed to list files at {current}: {e}")
            continue
        for item in items:
            if item["is_folder"]:
                if recursive:
                    queue.append(item["path"])
            else:
                all_files.append(item)
    return all_files
