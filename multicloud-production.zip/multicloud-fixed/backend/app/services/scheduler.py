"""
Scheduler helpers: compute next run time from schedule config.
"""
from datetime import datetime, timedelta, timezone
from app.models.transfer import ScheduleType


def compute_next_run(schedule_type: ScheduleType, config: dict = None) -> datetime:
    """Return the next scheduled run datetime based on schedule type."""
    now = datetime.now(timezone.utc)
    if schedule_type == ScheduleType.ONCE:
        if config and config.get("run_at"):
            return datetime.fromisoformat(config["run_at"])
        return now + timedelta(minutes=1)
    elif schedule_type == ScheduleType.HOURLY:
        return now + timedelta(hours=1)
    elif schedule_type == ScheduleType.DAILY:
        hour = config.get("hour", 0) if config else 0
        minute = config.get("minute", 0) if config else 0
        next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if next_run <= now:
            next_run += timedelta(days=1)
        return next_run
    elif schedule_type == ScheduleType.WEEKLY:
        return now + timedelta(weeks=1)
    elif schedule_type == ScheduleType.MONTHLY:
        if now.month == 12:
            return now.replace(year=now.year + 1, month=1, day=1)
        return now.replace(month=now.month + 1, day=1)
    return now + timedelta(days=1)


async def _run_due_tasks():
    """Find and dispatch all scheduled tasks that are due."""
    from sqlalchemy import select
    from app.core.database import AsyncSessionLocal
    from app.models.transfer import ScheduledTask, Transfer, TransferStatus, TransferMode
    from app.workers.transfer_worker import run_transfer_task

    now = datetime.now(timezone.utc)
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(ScheduledTask).where(
                ScheduledTask.is_active == True,
                ScheduledTask.next_run_at <= now,
            )
        )
        tasks = result.scalars().all()
        for task in tasks:
            transfer = Transfer(
                user_id=task.user_id,
                source_account_id=task.source_account_id,
                destination_account_id=task.destination_account_id,
                source_path=task.source_path,
                destination_path=task.destination_path,
                mode=TransferMode.COPY,
                status=TransferStatus.PENDING,
            )
            db.add(transfer)
            await db.commit()
            await db.refresh(transfer)

            celery_task = run_transfer_task.delay(transfer.id)
            transfer.celery_task_id = celery_task.id
            task.last_run_at = now
            task.run_count += 1
            task.next_run_at = compute_next_run(task.schedule_type, task.schedule_config)
            await db.commit()


def poll_scheduled_tasks():
    """Called by Celery beat — runs due scheduled tasks."""
    import asyncio
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_run_due_tasks())
    finally:
        loop.close()
