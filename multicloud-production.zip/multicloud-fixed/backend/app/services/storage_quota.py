"""
Refresh storage quota for a cloud account.
"""
import httpx
import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


async def refresh_storage_quota(account, db):
    """Fetch and update storage usage for the given cloud account."""
    from app.models.cloud_account import CloudProvider
    from app.core.encryption import decrypt_token

    try:
        if account.provider == CloudProvider.GOOGLE_DRIVE:
            access_token = decrypt_token(account.access_token_encrypted)
            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    "https://www.googleapis.com/drive/v3/about",
                    params={"fields": "storageQuota"},
                    headers={"Authorization": f"Bearer {access_token}"},
                )
                data = resp.json().get("storageQuota", {})
                account.storage_used_bytes = int(data.get("usage", 0))
                account.storage_total_bytes = int(data.get("limit", 0))

        elif account.provider == CloudProvider.ONEDRIVE:
            access_token = decrypt_token(account.access_token_encrypted)
            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    "https://graph.microsoft.com/v1.0/me/drive",
                    params={"select": "quota"},
                    headers={"Authorization": f"Bearer {access_token}"},
                )
                quota = resp.json().get("quota", {})
                account.storage_used_bytes = quota.get("used", 0)
                account.storage_total_bytes = quota.get("total", 0)

        elif account.provider == CloudProvider.DROPBOX:
            access_token = decrypt_token(account.access_token_encrypted)
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    "https://api.dropboxapi.com/2/users/get_space_usage",
                    headers={"Authorization": f"Bearer {access_token}"},
                )
                data = resp.json()
                account.storage_used_bytes = data.get("used", 0)
                alloc = data.get("allocation", {})
                account.storage_total_bytes = alloc.get("allocated", 0)

        account.storage_updated_at = datetime.now(timezone.utc)
        await db.commit()
    except Exception as e:
        logger.warning(f"Failed to refresh storage for account {account.id}: {e}")
