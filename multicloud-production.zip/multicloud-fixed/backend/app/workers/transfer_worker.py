"""
Celery worker: executes transfer tasks asynchronously.
"""
import asyncio
import logging
from datetime import datetime, timezone

from celery import Celery
from sqlalchemy import select

from app.core.config import settings

logger = logging.getLogger(__name__)

celery_app = Celery(
    "multicloud",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    worker_max_tasks_per_child=50,
)


def run_async(coro):
    """Run an async coroutine from a sync Celery task."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


@celery_app.task(bind=True, name="transfer.run", max_retries=3)
def run_transfer_task(self, transfer_id: str):
    """Main transfer task — runs in Celery worker."""
    run_async(_execute_transfer(self, transfer_id))


async def _execute_transfer(task, transfer_id: str):
    from app.core.database import AsyncSessionLocal
    from app.models.transfer import Transfer, TransferStatus
    from app.models.cloud_account import CloudAccount
    from app.services.cloud_adapter import get_adapter
    from app.services.transfer_engine import collect_all_files, stream_transfer

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Transfer).where(Transfer.id == transfer_id))
        transfer = result.scalar_one_or_none()
        if not transfer:
            logger.error(f"Transfer {transfer_id} not found")
            return

        # Check if already paused/cancelled before starting
        if transfer.status in (TransferStatus.PAUSED, TransferStatus.CANCELLED):
            return

        # Mark as running
        transfer.status = TransferStatus.RUNNING
        transfer.started_at = datetime.now(timezone.utc)
        await db.commit()

        try:
            src_result = await db.execute(select(CloudAccount).where(CloudAccount.id == transfer.source_account_id))
            src_account = src_result.scalar_one()
            dst_result = await db.execute(select(CloudAccount).where(CloudAccount.id == transfer.destination_account_id))
            dst_account = dst_result.scalar_one()

            src_adapter = await get_adapter(src_account)
            dst_adapter = await get_adapter(dst_account)

            # Collect all files
            files = await collect_all_files(src_adapter, transfer.source_path)
            transfer.total_files = len(files)
            transfer.total_bytes = sum(f.get("size", 0) for f in files)
            await db.commit()

            failed_files = []

            for file_item in files:
                # Re-check pause/cancel on each file
                await db.refresh(transfer)
                if transfer.status == TransferStatus.PAUSED:
                    logger.info(f"Transfer {transfer_id} paused at file {file_item['path']}")
                    return
                if transfer.status == TransferStatus.CANCELLED:
                    logger.info(f"Transfer {transfer_id} cancelled")
                    return

                # Compute destination path
                src_base = transfer.source_path.rstrip("/")
                rel_path = file_item["path"][len(src_base):]
                if not rel_path.startswith("/"):
                    rel_path = "/" + rel_path
                dest_path = transfer.destination_path.rstrip("/") + rel_path

                file_size = file_item.get("size", 0)

                async def on_progress(transferred_bytes: int, total: int, speed_bps: float,
                                      _t=transfer, _db=db):
                    _t.transferred_bytes += transferred_bytes
                    _t.transfer_speed_bps = speed_bps

                file_result = await stream_transfer(
                    src_adapter, dst_adapter,
                    file_item["path"], dest_path, file_size,
                    on_progress=on_progress,
                )

                if file_result["success"]:
                    transfer.transferred_files += 1
                else:
                    transfer.failed_files += 1
                    failed_files.append({
                        "path": file_item["path"],
                        "error": file_result.get("error", "Unknown error"),
                    })
                    logger.warning(f"File failed: {file_item['path']}: {file_result.get('error')}")

                await db.commit()

            # Finalize
            transfer.status = TransferStatus.COMPLETED if not failed_files else TransferStatus.FAILED
            transfer.completed_at = datetime.now(timezone.utc)
            if failed_files:
                transfer.failed_files_log = failed_files
                transfer.error_message = f"{len(failed_files)} file(s) failed"
            transfer.transfer_speed_bps = 0.0
            await db.commit()
            logger.info(f"Transfer {transfer_id} completed: {transfer.transferred_files}/{transfer.total_files} files")

        except Exception as exc:
            logger.exception(f"Transfer {transfer_id} failed with exception: {exc}")
            transfer.status = TransferStatus.FAILED
            transfer.error_message = str(exc)
            transfer.completed_at = datetime.now(timezone.utc)
            await db.commit()
            raise
