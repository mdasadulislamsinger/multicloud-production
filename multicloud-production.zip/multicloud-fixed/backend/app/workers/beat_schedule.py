"""
Celery Beat schedule — polls for due scheduled tasks every minute.
"""
from app.workers.transfer_worker import celery_app
from app.services.scheduler import poll_scheduled_tasks

# Register the poll task with celery
@celery_app.task(name="scheduler.poll")
def celery_poll_scheduled_tasks():
    poll_scheduled_tasks()


celery_app.conf.beat_schedule = {
    "poll-scheduled-tasks": {
        "task": "scheduler.poll",
        "schedule": 60.0,  # every 60 seconds
    },
}
