"""
CloudAccount model - stores connected cloud service credentials.
"""
import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, ForeignKey, Text, func, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from app.core.database import Base


class CloudProvider(str, enum.Enum):
    GOOGLE_DRIVE = "google_drive"
    ONEDRIVE = "onedrive"
    DROPBOX = "dropbox"
    BOX = "box"
    S3 = "s3"
    FTP = "ftp"
    SFTP = "sftp"


class CloudAccount(Base):
    __tablename__ = "cloud_accounts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    provider: Mapped[CloudProvider] = mapped_column(SAEnum(CloudProvider), nullable=False)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)
    account_email: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Encrypted OAuth tokens
    access_token_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    refresh_token_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    token_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # S3 / FTP specific (encrypted)
    credentials_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON blob

    # Storage info (refreshed periodically)
    storage_used_bytes: Mapped[int] = mapped_column(default=0)
    storage_total_bytes: Mapped[int] = mapped_column(default=0)
    storage_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="cloud_accounts")
