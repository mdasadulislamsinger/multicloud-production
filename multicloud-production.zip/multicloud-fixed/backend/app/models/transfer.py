"""
Transfer and ScheduledTask models.
"""
import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, ForeignKey, Text, Integer, Float, func, Enum as SAEnum, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from app.core.database import Base


class TransferStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TransferMode(str, enum.Enum):
    COPY = "copy"
    MOVE = "move"
    MIRROR = "mirror"


class Transfer(Base):
    __tablename__ = "transfers"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    source_account_id: Mapped[str] = mapped_column(String(36), ForeignKey("cloud_accounts.id"), nullable=False)
    destination_account_id: Mapped[str] = mapped_column(String(36), ForeignKey("cloud_accounts.id"), nullable=False)

    source_path: Mapped[str] = mapped_column(String(1024), nullable=False)
    destination_path: Mapped[str] = mapped_column(String(1024), nullable=False)

    mode: Mapped[TransferMode] = mapped_column(SAEnum(TransferMode), default=TransferMode.COPY)
    status: Mapped[TransferStatus] = mapped_column(SAEnum(TransferStatus), default=TransferStatus.PENDING, index=True)

    # Progress tracking
    total_files: Mapped[int] = mapped_column(Integer, default=0)
    transferred_files: Mapped[int] = mapped_column(Integer, default=0)
    failed_files: Mapped[int] = mapped_column(Integer, default=0)
    total_bytes: Mapped[int] = mapped_column(Integer, default=0)
    transferred_bytes: Mapped[int] = mapped_column(Integer, default=0)
    transfer_speed_bps: Mapped[float] = mapped_column(Float, default=0.0)

    # Celery task reference
    celery_task_id: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Error info
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    failed_files_log: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Checksum verification
    checksum_verified: Mapped[bool] = mapped_column(default=False)

    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="transfers")
    source_account: Mapped["CloudAccount"] = relationship("CloudAccount", foreign_keys=[source_account_id])
    destination_account: Mapped["CloudAccount"] = relationship("CloudAccount", foreign_keys=[destination_account_id])


class ScheduleType(str, enum.Enum):
    ONCE = "once"
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


class TaskType(str, enum.Enum):
    TRANSFER = "transfer"
    SYNC = "sync"
    BACKUP = "backup"


class ScheduledTask(Base):
    __tablename__ = "scheduled_tasks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    task_type: Mapped[TaskType] = mapped_column(SAEnum(TaskType), nullable=False)

    source_account_id: Mapped[str] = mapped_column(String(36), ForeignKey("cloud_accounts.id"), nullable=False)
    destination_account_id: Mapped[str] = mapped_column(String(36), ForeignKey("cloud_accounts.id"), nullable=False)
    source_path: Mapped[str] = mapped_column(String(1024), nullable=False)
    destination_path: Mapped[str] = mapped_column(String(1024), nullable=False)

    schedule_type: Mapped[ScheduleType] = mapped_column(SAEnum(ScheduleType), nullable=False)
    schedule_config: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # cron expression or specific time

    is_active: Mapped[bool] = mapped_column(default=True)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    run_count: Mapped[int] = mapped_column(Integer, default=0)

    celery_task_id: Mapped[str | None] = mapped_column(String(255), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="scheduled_tasks")
    source_account: Mapped["CloudAccount"] = relationship("CloudAccount", foreign_keys=[source_account_id])
    destination_account: Mapped["CloudAccount"] = relationship("CloudAccount", foreign_keys=[destination_account_id])
