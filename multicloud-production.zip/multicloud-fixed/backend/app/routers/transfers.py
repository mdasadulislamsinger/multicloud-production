"""
Transfers router: create, list, pause, resume, cancel, and WebSocket progress.
"""
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import Optional
from pydantic import BaseModel
import asyncio
import json

from app.core.database import get_db
from app.core.security import get_current_user, decode_token
from app.models.user import User
from app.models.cloud_account import CloudAccount
from app.models.transfer import Transfer, TransferStatus, TransferMode
from app.workers.transfer_worker import run_transfer_task

router = APIRouter()


class CreateTransferRequest(BaseModel):
    source_account_id: str
    destination_account_id: str
    source_path: str
    destination_path: str
    mode: TransferMode = TransferMode.COPY


class TransferResponse(BaseModel):
    id: str
    status: str
    source_account_id: str
    destination_account_id: str
    source_path: str
    destination_path: str
    mode: str
    total_files: int
    transferred_files: int
    failed_files: int
    total_bytes: int
    transferred_bytes: int
    transfer_speed_bps: float
    created_at: datetime
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    error_message: Optional[str]

    class Config:
        from_attributes = True


async def _get_account(account_id: str, user: User, db: AsyncSession) -> CloudAccount:
    result = await db.execute(
        select(CloudAccount).where(
            CloudAccount.id == account_id,
            CloudAccount.user_id == user.id,
            CloudAccount.is_active == True,
        )
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail=f"Account {account_id} not found")
    return account


@router.post("/", response_model=TransferResponse)
async def create_transfer(
    body: CreateTransferRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _get_account(body.source_account_id, current_user, db)
    await _get_account(body.destination_account_id, current_user, db)

    if body.source_account_id == body.destination_account_id and body.source_path == body.destination_path:
        raise HTTPException(status_code=400, detail="Source and destination cannot be identical")

    transfer = Transfer(
        user_id=current_user.id,
        source_account_id=body.source_account_id,
        destination_account_id=body.destination_account_id,
        source_path=body.source_path,
        destination_path=body.destination_path,
        mode=body.mode,
        status=TransferStatus.PENDING,
    )
    db.add(transfer)
    await db.commit()
    await db.refresh(transfer)

    # Dispatch Celery task
    task = run_transfer_task.delay(transfer.id)
    transfer.celery_task_id = task.id
    await db.commit()

    return transfer


@router.get("/", response_model=list[TransferResponse])
async def list_transfers(
    status: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    query = select(Transfer).where(Transfer.user_id == current_user.id)
    if status:
        query = query.where(Transfer.status == status)
    query = query.order_by(desc(Transfer.created_at)).limit(limit).offset(offset)
    result = await db.execute(query)
    return result.scalars().all()


@router.get("/{transfer_id}", response_model=TransferResponse)
async def get_transfer(
    transfer_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Transfer).where(Transfer.id == transfer_id, Transfer.user_id == current_user.id)
    )
    transfer = result.scalar_one_or_none()
    if not transfer:
        raise HTTPException(status_code=404, detail="Transfer not found")
    return transfer


@router.post("/{transfer_id}/pause")
async def pause_transfer(
    transfer_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Transfer).where(Transfer.id == transfer_id, Transfer.user_id == current_user.id)
    )
    transfer = result.scalar_one_or_none()
    if not transfer:
        raise HTTPException(status_code=404, detail="Transfer not found")
    if transfer.status != TransferStatus.RUNNING:
        raise HTTPException(status_code=400, detail="Transfer is not running")
    transfer.status = TransferStatus.PAUSED
    await db.commit()
    return {"message": "Transfer paused"}


@router.post("/{transfer_id}/resume")
async def resume_transfer(
    transfer_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Transfer).where(Transfer.id == transfer_id, Transfer.user_id == current_user.id)
    )
    transfer = result.scalar_one_or_none()
    if not transfer:
        raise HTTPException(status_code=404, detail="Transfer not found")
    if transfer.status != TransferStatus.PAUSED:
        raise HTTPException(status_code=400, detail="Transfer is not paused")
    transfer.status = TransferStatus.PENDING
    await db.commit()
    # Re-dispatch
    task = run_transfer_task.delay(transfer.id)
    transfer.celery_task_id = task.id
    await db.commit()
    return {"message": "Transfer resumed"}


@router.post("/{transfer_id}/cancel")
async def cancel_transfer(
    transfer_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Transfer).where(Transfer.id == transfer_id, Transfer.user_id == current_user.id)
    )
    transfer = result.scalar_one_or_none()
    if not transfer:
        raise HTTPException(status_code=404, detail="Transfer not found")
    if transfer.status in (TransferStatus.COMPLETED, TransferStatus.CANCELLED):
        raise HTTPException(status_code=400, detail="Transfer already finished")
    transfer.status = TransferStatus.CANCELLED
    await db.commit()
    return {"message": "Transfer cancelled"}


# ─── WebSocket progress ────────────────────────────────────────────────────────

@router.websocket("/ws/{transfer_id}")
async def transfer_progress_ws(
    websocket: WebSocket,
    transfer_id: str,
    token: str = Query(...),
):
    """WebSocket endpoint for real-time transfer progress.
    Connect with: ws://host/api/v1/transfers/ws/{transfer_id}?token=<access_token>
    """
    # Authenticate via token query param
    try:
        payload = decode_token(token)
        user_id = payload.get("sub")
    except Exception:
        await websocket.close(code=4001, reason="Unauthorized")
        return

    await websocket.accept()

    from app.core.database import AsyncSessionLocal
    try:
        while True:
            async with AsyncSessionLocal() as db:
                result = await db.execute(
                    select(Transfer).where(
                        Transfer.id == transfer_id,
                        Transfer.user_id == user_id,
                    )
                )
                transfer = result.scalar_one_or_none()
                if not transfer:
                    await websocket.send_json({"error": "Transfer not found"})
                    break

                pct = 0
                if transfer.total_bytes > 0:
                    pct = round((transfer.transferred_bytes / transfer.total_bytes) * 100, 1)
                elif transfer.total_files > 0:
                    pct = round((transfer.transferred_files / transfer.total_files) * 100, 1)

                speed_mbps = round(transfer.transfer_speed_bps / (1024 * 1024), 2) if transfer.transfer_speed_bps else 0
                eta_seconds = None
                if transfer.transfer_speed_bps > 0 and transfer.total_bytes > transfer.transferred_bytes:
                    eta_seconds = int((transfer.total_bytes - transfer.transferred_bytes) / transfer.transfer_speed_bps)

                await websocket.send_json({
                    "transfer_id": transfer.id,
                    "status": transfer.status,
                    "percent": pct,
                    "transferred_files": transfer.transferred_files,
                    "total_files": transfer.total_files,
                    "failed_files": transfer.failed_files,
                    "transferred_bytes": transfer.transferred_bytes,
                    "total_bytes": transfer.total_bytes,
                    "speed_mbps": speed_mbps,
                    "eta_seconds": eta_seconds,
                    "error_message": transfer.error_message,
                })

                if transfer.status in (
                    TransferStatus.COMPLETED,
                    TransferStatus.FAILED,
                    TransferStatus.CANCELLED,
                ):
                    break

            await asyncio.sleep(1)
    except WebSocketDisconnect:
        pass
    finally:
        await websocket.close()
