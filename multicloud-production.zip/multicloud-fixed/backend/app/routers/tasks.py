"""
Scheduled tasks router.
"""
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import Optional
from pydantic import BaseModel

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.transfer import ScheduledTask, ScheduleType, TaskType

router = APIRouter()


class CreateTaskRequest(BaseModel):
    name: str
    task_type: TaskType
    source_account_id: str
    destination_account_id: str
    source_path: str
    destination_path: str
    schedule_type: ScheduleType
    schedule_config: Optional[dict] = None


class TaskResponse(BaseModel):
    id: str
    name: str
    task_type: str
    source_account_id: str
    destination_account_id: str
    source_path: str
    destination_path: str
    schedule_type: str
    is_active: bool
    last_run_at: Optional[datetime]
    next_run_at: Optional[datetime]
    run_count: int
    created_at: datetime

    class Config:
        from_attributes = True


@router.post("/", response_model=TaskResponse)
async def create_task(
    body: CreateTaskRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.services.scheduler import compute_next_run
    next_run = compute_next_run(body.schedule_type, body.schedule_config)

    task = ScheduledTask(
        user_id=current_user.id,
        name=body.name,
        task_type=body.task_type,
        source_account_id=body.source_account_id,
        destination_account_id=body.destination_account_id,
        source_path=body.source_path,
        destination_path=body.destination_path,
        schedule_type=body.schedule_type,
        schedule_config=body.schedule_config,
        next_run_at=next_run,
    )
    db.add(task)
    await db.commit()
    await db.refresh(task)
    return task


@router.get("/", response_model=list[TaskResponse])
async def list_tasks(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(ScheduledTask)
        .where(ScheduledTask.user_id == current_user.id)
        .order_by(desc(ScheduledTask.created_at))
    )
    return result.scalars().all()


@router.patch("/{task_id}/toggle")
async def toggle_task(
    task_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(ScheduledTask).where(ScheduledTask.id == task_id, ScheduledTask.user_id == current_user.id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    task.is_active = not task.is_active
    await db.commit()
    return {"is_active": task.is_active}


@router.delete("/{task_id}")
async def delete_task(
    task_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(ScheduledTask).where(ScheduledTask.id == task_id, ScheduledTask.user_id == current_user.id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    await db.delete(task)
    await db.commit()
    return {"message": "Task deleted"}
