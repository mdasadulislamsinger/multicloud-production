"""
Webhooks router (for future cloud push notifications).
"""
from fastapi import APIRouter, Request

router = APIRouter()


@router.post("/google-drive/changes")
async def google_drive_webhook(request: Request):
    """Handle Google Drive push notifications."""
    return {"status": "ok"}
