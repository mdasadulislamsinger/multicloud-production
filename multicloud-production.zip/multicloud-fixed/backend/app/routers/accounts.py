"""
Cloud accounts router: connect, list, disconnect cloud services.
"""
import json
import httpx
from urllib.parse import urlencode
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional

from app.core.config import settings
from app.core.database import get_db
from app.core.security import get_current_user
from app.core.encryption import encrypt_token, decrypt_token
from app.models.user import User
from app.models.cloud_account import CloudAccount, CloudProvider
from app.services.storage_quota import refresh_storage_quota

router = APIRouter()


class AccountResponse(BaseModel):
    id: str
    provider: str
    display_name: str
    account_email: Optional[str]
    storage_used_bytes: int
    storage_total_bytes: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class S3CredentialsRequest(BaseModel):
    display_name: str
    access_key_id: str
    secret_access_key: str
    region: str = "us-east-1"
    bucket_name: Optional[str] = None


class FTPCredentialsRequest(BaseModel):
    display_name: str
    host: str
    port: int = 21
    username: str
    password: str
    protocol: str = "ftp"  # ftp or sftp


# ─── List accounts ─────────────────────────────────────────────────────────────

@router.get("/", response_model=list[AccountResponse])
async def list_accounts(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(CloudAccount)
        .where(CloudAccount.user_id == current_user.id, CloudAccount.is_active == True)
        .order_by(CloudAccount.created_at.asc())
    )
    return result.scalars().all()


# ─── Google Drive OAuth ────────────────────────────────────────────────────────

@router.get("/google-drive/connect")
async def connect_google_drive(current_user: User = Depends(get_current_user)):
    params = {
        "client_id": settings.GOOGLE_CLIENT_ID,
        "redirect_uri": f"{settings.BACKEND_URL}/api/v1/accounts/google-drive/callback",
        "response_type": "code",
        "scope": "https://www.googleapis.com/auth/drive",
        "access_type": "offline",
        "prompt": "consent",
        "state": current_user.id,
    }
    return {"auth_url": "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(params)}


@router.get("/google-drive/callback")
async def google_drive_callback(code: str, state: str, db: AsyncSession = Depends(get_db)):
    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            "https://oauth2.googleapis.com/token",
            data={
                "code": code,
                "client_id": settings.GOOGLE_CLIENT_ID,
                "client_secret": settings.GOOGLE_CLIENT_SECRET,
                "redirect_uri": f"{settings.BACKEND_URL}/api/v1/accounts/google-drive/callback",
                "grant_type": "authorization_code",
            },
        )
        token_data = token_resp.json()
        user_resp = await client.get(
            "https://www.googleapis.com/oauth2/v2/userinfo",
            headers={"Authorization": f"Bearer {token_data['access_token']}"},
        )
        user_info = user_resp.json()

    account = CloudAccount(
        user_id=state,
        provider=CloudProvider.GOOGLE_DRIVE,
        display_name=f"Google Drive ({user_info.get('email', '')})",
        account_email=user_info.get("email"),
        access_token_encrypted=encrypt_token(token_data["access_token"]),
        refresh_token_encrypted=encrypt_token(token_data.get("refresh_token", "")),
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    await refresh_storage_quota(account, db)

    return RedirectResponse(f"{settings.FRONTEND_URL}/dashboard?connected=google_drive")


# ─── OneDrive OAuth ────────────────────────────────────────────────────────────

@router.get("/onedrive/connect")
async def connect_onedrive(current_user: User = Depends(get_current_user)):
    params = {
        "client_id": settings.MICROSOFT_CLIENT_ID,
        "redirect_uri": f"{settings.BACKEND_URL}/api/v1/accounts/onedrive/callback",
        "response_type": "code",
        "scope": "Files.ReadWrite.All offline_access User.Read",
        "state": current_user.id,
    }
    url = f"https://login.microsoftonline.com/{settings.MICROSOFT_TENANT_ID}/oauth2/v2.0/authorize?" + urlencode(params)
    return {"auth_url": url}


@router.get("/onedrive/callback")
async def onedrive_callback(code: str, state: str, db: AsyncSession = Depends(get_db)):
    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            f"https://login.microsoftonline.com/{settings.MICROSOFT_TENANT_ID}/oauth2/v2.0/token",
            data={
                "code": code,
                "client_id": settings.MICROSOFT_CLIENT_ID,
                "client_secret": settings.MICROSOFT_CLIENT_SECRET,
                "redirect_uri": f"{settings.BACKEND_URL}/api/v1/accounts/onedrive/callback",
                "grant_type": "authorization_code",
            },
        )
        token_data = token_resp.json()
        user_resp = await client.get(
            "https://graph.microsoft.com/v1.0/me",
            headers={"Authorization": f"Bearer {token_data['access_token']}"},
        )
        user_info = user_resp.json()

    email = user_info.get("mail") or user_info.get("userPrincipalName", "")
    account = CloudAccount(
        user_id=state,
        provider=CloudProvider.ONEDRIVE,
        display_name=f"OneDrive ({email})",
        account_email=email,
        access_token_encrypted=encrypt_token(token_data["access_token"]),
        refresh_token_encrypted=encrypt_token(token_data.get("refresh_token", "")),
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    await refresh_storage_quota(account, db)
    return RedirectResponse(f"{settings.FRONTEND_URL}/dashboard?connected=onedrive")


# ─── Dropbox OAuth ─────────────────────────────────────────────────────────────

@router.get("/dropbox/connect")
async def connect_dropbox(current_user: User = Depends(get_current_user)):
    params = {
        "client_id": settings.DROPBOX_APP_KEY,
        "redirect_uri": f"{settings.BACKEND_URL}/api/v1/accounts/dropbox/callback",
        "response_type": "code",
        "token_access_type": "offline",
        "state": current_user.id,
    }
    return {"auth_url": "https://www.dropbox.com/oauth2/authorize?" + urlencode(params)}


@router.get("/dropbox/callback")
async def dropbox_callback(code: str, state: str, db: AsyncSession = Depends(get_db)):
    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            "https://api.dropboxapi.com/oauth2/token",
            data={
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": f"{settings.BACKEND_URL}/api/v1/accounts/dropbox/callback",
            },
            auth=(settings.DROPBOX_APP_KEY, settings.DROPBOX_APP_SECRET),
        )
        token_data = token_resp.json()

    account = CloudAccount(
        user_id=state,
        provider=CloudProvider.DROPBOX,
        display_name=f"Dropbox ({token_data.get('email', '')})",
        account_email=token_data.get("email"),
        access_token_encrypted=encrypt_token(token_data["access_token"]),
        refresh_token_encrypted=encrypt_token(token_data.get("refresh_token", "")),
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    await refresh_storage_quota(account, db)
    return RedirectResponse(f"{settings.FRONTEND_URL}/dashboard?connected=dropbox")


# ─── Amazon S3 ─────────────────────────────────────────────────────────────────

@router.post("/s3")
async def connect_s3(
    body: S3CredentialsRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    creds = {
        "access_key_id": body.access_key_id,
        "secret_access_key": body.secret_access_key,
        "region": body.region,
        "bucket_name": body.bucket_name,
    }
    account = CloudAccount(
        user_id=current_user.id,
        provider=CloudProvider.S3,
        display_name=body.display_name,
        credentials_encrypted=encrypt_token(json.dumps(creds)),
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    return {"id": account.id, "display_name": account.display_name, "provider": account.provider}


# ─── FTP / SFTP ────────────────────────────────────────────────────────────────

@router.post("/ftp")
async def connect_ftp(
    body: FTPCredentialsRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    creds = {
        "host": body.host,
        "port": body.port,
        "username": body.username,
        "password": body.password,
        "protocol": body.protocol,
    }
    provider = CloudProvider.SFTP if body.protocol == "sftp" else CloudProvider.FTP
    account = CloudAccount(
        user_id=current_user.id,
        provider=provider,
        display_name=body.display_name,
        account_email=f"{body.username}@{body.host}",
        credentials_encrypted=encrypt_token(json.dumps(creds)),
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    return {"id": account.id, "display_name": account.display_name, "provider": account.provider}


# ─── Disconnect ────────────────────────────────────────────────────────────────

@router.delete("/{account_id}")
async def disconnect_account(
    account_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(CloudAccount).where(
            CloudAccount.id == account_id,
            CloudAccount.user_id == current_user.id,
        )
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    account.is_active = False
    await db.commit()
    return {"message": "Account disconnected"}
