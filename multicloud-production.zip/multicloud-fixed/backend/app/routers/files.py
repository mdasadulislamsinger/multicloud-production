"""
Files router: browse, list, delete, rename, move files in connected clouds.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional
from pydantic import BaseModel

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.cloud_account import CloudAccount
from app.services.cloud_adapter import get_adapter

router = APIRouter()


class FileItem(BaseModel):
    id: str
    name: str
    path: str
    is_folder: bool
    size: Optional[int] = None
    modified_at: Optional[str] = None
    mime_type: Optional[str] = None


class RenameRequest(BaseModel):
    new_name: str


class MoveRequest(BaseModel):
    destination_path: str


async def _get_account(account_id: str, user: User, db: AsyncSession) -> CloudAccount:
    result = await db.execute(
        select(CloudAccount).where(
            CloudAccount.id == account_id,
            CloudAccount.user_id == user.id,
            CloudAccount.is_active == True,
        )
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Cloud account not found")
    return account


@router.get("/{account_id}/list")
async def list_files(
    account_id: str,
    path: str = Query(default="/", description="Folder path to list"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    account = await _get_account(account_id, current_user, db)
    adapter = await get_adapter(account)
    files = await adapter.list_files(path)
    return {"path": path, "files": files}


@router.delete("/{account_id}/files")
async def delete_file(
    account_id: str,
    path: str = Query(..., description="File path to delete"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    account = await _get_account(account_id, current_user, db)
    adapter = await get_adapter(account)
    await adapter.delete(path)
    return {"message": f"Deleted: {path}"}


@router.post("/{account_id}/rename")
async def rename_file(
    account_id: str,
    path: str = Query(...),
    body: RenameRequest = ...,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    account = await _get_account(account_id, current_user, db)
    adapter = await get_adapter(account)
    await adapter.rename(path, body.new_name)
    return {"message": "Renamed successfully"}


@router.post("/{account_id}/move")
async def move_file(
    account_id: str,
    path: str = Query(...),
    body: MoveRequest = ...,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    account = await _get_account(account_id, current_user, db)
    adapter = await get_adapter(account)
    await adapter.move(path, body.destination_path)
    return {"message": "Moved successfully"}


@router.post("/{account_id}/mkdir")
async def create_folder(
    account_id: str,
    path: str = Query(..., description="New folder path"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    account = await _get_account(account_id, current_user, db)
    adapter = await get_adapter(account)
    await adapter.create_folder(path)
    return {"message": f"Folder created: {path}"}
